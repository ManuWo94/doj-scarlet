<?php
/**
 * Konfigurationsdatei für die Fraktionsverwaltung
 */

// Fehlermeldungen anzeigen (in Produktion auf false setzen)
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Zeitzone setzen
date_default_timezone_set('Europe/Berlin');

// Pfade für Datenspeicherung
define('DATA_DIR', __DIR__ . '/../data');
define('FRAKTIONEN_FILE', DATA_DIR . '/fraktionen.json');
define('ITEMS_FILE', DATA_DIR . '/items.json');
define('MATERIALIEN_FILE', DATA_DIR . '/materialien.json');
define('AKTIVITÄTEN_FILE', DATA_DIR . '/aktivitaeten.json');
define('BENUTZER_FILE', DATA_DIR . '/benutzer.json');

// Maximale Anzahl der Aktivitäten, die gespeichert werden
define('MAX_AKTIVITÄTEN', 100);

// Stellen Sie sicher, dass das Datenverzeichnis existiert
if (!file_exists(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}

// Hilfsfunktion für die ID-Generierung bei der Initialisierung
function generateInitialId() {
    return uniqid() . '_' . mt_rand(1000, 9999);
}

// Initialisiere JSON-Dateien, falls sie nicht existieren
$initialFiles = [
    FRAKTIONEN_FILE => [],
    ITEMS_FILE => [],
    MATERIALIEN_FILE => [],
    AKTIVITÄTEN_FILE => [],
    BENUTZER_FILE => [
        [
            'id' => generateInitialId(),
            'username' => 'Manu',
            'password' => password_hash('admin', PASSWORD_DEFAULT),
            'role' => 'admin',
            'password_reset_required' => false,
            'created_at' => date('Y-m-d H:i:s')
        ]
    ]
];

foreach ($initialFiles as $file => $defaultValue) {
    if (!file_exists($file)) {
        file_put_contents($file, json_encode($defaultValue, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        chmod($file, 0644);
    }
}

// Website-Einstellungen
$config = [
    'siteTitle' => 'Fraktionsverwaltung',
    'version' => '1.0.0',
    'author' => 'Fraktionssupporter'
];
