<?php
/**
 * Benutzerverwaltung für die Fraktionsverwaltung
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Wenn der Benutzer kein Admin ist, verweigere Zugriff
if (!isAdmin()) {
    header('Location: dashboard.php?error=Zugriff+verweigert');
    exit;
}

$error = '';
$success = '';
$benutzer = getBenutzer();

// Neuen Benutzer erstellen
if (isset($_POST['action']) && $_POST['action'] === 'create') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $canEdit = isset($_POST['can_edit']) && $_POST['can_edit'] === '1';
    
    if (empty($username) || empty($password)) {
        $error = 'Bitte fülle alle Pflichtfelder aus.';
    } elseif (strlen($password) < 6) {
        $error = 'Das Passwort muss mindestens 6 Zeichen lang sein.';
    } else {
        $created = createBenutzer($username, $password, $canEdit);
        
        if ($created) {
            logAktivität('fa-user-plus', 'Benutzer ' . $username . ' wurde erstellt.');
            $success = 'Benutzer wurde erfolgreich erstellt.';
            $benutzer = getBenutzer(); // Aktualisiere die Benutzerliste
        } else {
            $error = 'Der Benutzername existiert bereits oder es gab einen Fehler beim Erstellen.';
        }
    }
}

// Benutzer-Rechte aktualisieren
if (isset($_POST['action']) && $_POST['action'] === 'update') {
    $userId = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $canEdit = isset($_POST['can_edit']) && $_POST['can_edit'] === '1';
    
    if (empty($userId)) {
        $error = 'Ungültige Benutzer-ID.';
    } else {
        $user = getBenutzerById($userId);
        
        if ($user) {
            $updated = updateBenutzer($userId, [
                'can_edit' => $canEdit
            ]);
            
            if ($updated) {
                logAktivität('fa-user-edit', 'Rechte von Benutzer ' . $user['username'] . ' wurden aktualisiert.');
                $success = 'Benutzerrechte wurden erfolgreich aktualisiert.';
                $benutzer = getBenutzer(); // Aktualisiere die Benutzerliste
            } else {
                $error = 'Fehler beim Aktualisieren der Benutzerrechte.';
            }
        } else {
            $error = 'Benutzer nicht gefunden.';
        }
    }
}

// Passwort zurücksetzen
if (isset($_POST['action']) && $_POST['action'] === 'reset_password') {
    $userId = isset($_POST['user_id']) ? $_POST['user_id'] : '';
    $newPassword = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    
    if (empty($userId) || empty($newPassword)) {
        $error = 'Bitte fülle alle Pflichtfelder aus.';
    } elseif (strlen($newPassword) < 6) {
        $error = 'Das Passwort muss mindestens 6 Zeichen lang sein.';
    } else {
        $user = getBenutzerById($userId);
        
        if ($user) {
            $updated = updateBenutzer($userId, [
                'password' => password_hash($newPassword, PASSWORD_DEFAULT),
                'password_reset_required' => true
            ]);
            
            if ($updated) {
                logAktivität('fa-key', 'Passwort von Benutzer ' . $user['username'] . ' wurde zurückgesetzt.');
                $success = 'Das Passwort wurde erfolgreich zurückgesetzt. Der Benutzer muss sein Passwort bei der nächsten Anmeldung ändern.';
            } else {
                $error = 'Fehler beim Zurücksetzen des Passworts.';
            }
        } else {
            $error = 'Benutzer nicht gefunden.';
        }
    }
}

// Benutzer löschen
if (isset($_GET['delete'])) {
    $userId = $_GET['delete'];
    $user = getBenutzerById($userId);
    
    if ($user && $user['role'] !== 'admin') {
        $deleted = deleteBenutzer($userId);
        
        if ($deleted) {
            logAktivität('fa-user-times', 'Benutzer ' . $user['username'] . ' wurde gelöscht.');
            $success = 'Benutzer wurde erfolgreich gelöscht.';
            $benutzer = getBenutzer(); // Aktualisiere die Benutzerliste
        } else {
            $error = 'Fehler beim Löschen des Benutzers.';
        }
    } else {
        $error = 'Admin-Benutzer kann nicht gelöscht werden.';
    }
}

// Seiten-Header
$pageTitle = 'Benutzerverwaltung';
include 'includes/header.php';
?>

<div class="container-fluid mt-3">
    <div class="card bg-dark text-white mb-4">
        <div class="card-header d-flex justify-content-between">
            <h4 class="mb-0">
                <i class="fas fa-users"></i> Benutzerverwaltung
            </h4>
            <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#new-user-modal">
                <i class="fas fa-user-plus"></i> Neuer Benutzer
            </button>
        </div>
        <div class="card-body">
            <?php if (!empty($error)) : ?>
            <div class="alert alert-danger">
                <?php echo htmlspecialchars($error); ?>
            </div>
            <?php endif; ?>
            
            <?php if (!empty($success)) : ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success); ?>
            </div>
            <?php endif; ?>
            
            <div class="table-responsive">
                <table class="table table-dark table-hover">
                    <thead>
                        <tr>
                            <th>Benutzername</th>
                            <th>Rolle</th>
                            <th>Bearbeitungsrechte</th>
                            <th>Erstellt am</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($benutzer as $user) : ?>
                        <tr>
                            <td><?php echo htmlspecialchars($user['username']); ?></td>
                            <td>
                                <span class="badge bg-<?php echo $user['role'] === 'admin' ? 'danger' : 'primary'; ?>">
                                    <?php echo $user['role'] === 'admin' ? 'Administrator' : 'Benutzer'; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($user['role'] === 'admin') : ?>
                                <span class="badge bg-info">Vollzugriff</span>
                                <?php else : ?>
                                <span class="badge bg-<?php echo isset($user['can_edit']) && $user['can_edit'] ? 'success' : 'secondary'; ?>">
                                    <?php echo isset($user['can_edit']) && $user['can_edit'] ? 'Bearbeiten erlaubt' : 'Nur Lesen'; ?>
                                </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php echo isset($user['created_at']) ? date('d.m.Y H:i', strtotime($user['created_at'])) : '-'; ?>
                            </td>
                            <td>
                                <?php if ($user['role'] !== 'admin' || (isAdmin() && $_SESSION['user_id'] === $user['id'])) : ?>
                                <div class="btn-group btn-group-sm">
                                    <?php if ($user['role'] !== 'admin') : ?>
                                    <button type="button" class="btn btn-outline-primary edit-rights-btn" 
                                            data-id="<?php echo $user['id']; ?>" 
                                            data-username="<?php echo htmlspecialchars($user['username']); ?>"
                                            data-can-edit="<?php echo isset($user['can_edit']) && $user['can_edit'] ? '1' : '0'; ?>">
                                        <i class="fas fa-user-edit"></i> Rechte
                                    </button>
                                    
                                    <button type="button" class="btn btn-outline-warning reset-password-btn" 
                                            data-id="<?php echo $user['id']; ?>" 
                                            data-username="<?php echo htmlspecialchars($user['username']); ?>">
                                        <i class="fas fa-key"></i> Passwort
                                    </button>
                                    
                                    <button type="button" class="btn btn-outline-danger delete-user" 
                                            data-id="<?php echo $user['id']; ?>" 
                                            data-username="<?php echo htmlspecialchars($user['username']); ?>">
                                        <i class="fas fa-trash"></i> Löschen
                                    </button>
                                    <?php else : ?>
                                    <a href="password_reset.php?change=1" class="btn btn-outline-warning">
                                        <i class="fas fa-key"></i> Passwort ändern
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php else : ?>
                                <span class="text-muted">Keine Aktionen verfügbar</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Neuer Benutzer Modal -->
<div class="modal fade" id="new-user-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Neuen Benutzer erstellen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="benutzer.php">
                    <input type="hidden" name="action" value="create">
                    <div class="mb-3">
                        <label for="username" class="form-label">Benutzername</label>
                        <input type="text" class="form-control" id="username" name="username" required>
                    </div>
                    <div class="mb-3">
                        <label for="password" class="form-label">Passwort</label>
                        <input type="text" class="form-control" id="password" name="password" required>
                        <div class="form-text text-muted">
                            Mindestens 6 Zeichen. Der Benutzer muss das Passwort bei der ersten Anmeldung ändern.
                        </div>
                    </div>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="can_edit" name="can_edit" value="1">
                        <label class="form-check-label" for="can_edit">Darf Inhalte bearbeiten</label>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Abbrechen</button>
                        <button type="submit" class="btn btn-primary">Benutzer erstellen</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Benutzerrechte Modal -->
<div class="modal fade" id="edit-rights-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Benutzerrechte bearbeiten</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="benutzer.php">
                    <input type="hidden" name="action" value="update">
                    <input type="hidden" name="user_id" id="edit-user-id">
                    <p>Bearbeite die Rechte für <strong id="edit-username"></strong>:</p>
                    <div class="mb-3 form-check">
                        <input type="checkbox" class="form-check-input" id="edit_can_edit" name="can_edit" value="1">
                        <label class="form-check-label" for="edit_can_edit">Darf Inhalte bearbeiten</label>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Abbrechen</button>
                        <button type="submit" class="btn btn-primary">Rechte speichern</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Passwort zurücksetzen Modal -->
<div class="modal fade" id="reset-password-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Passwort zurücksetzen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form method="post" action="benutzer.php">
                    <input type="hidden" name="action" value="reset_password">
                    <input type="hidden" name="user_id" id="reset-user-id">
                    <p>Setze das Passwort für <strong id="reset-username"></strong> zurück:</p>
                    <div class="mb-3">
                        <label for="new_password" class="form-label">Neues Passwort</label>
                        <input type="text" class="form-control" id="new_password" name="new_password" required>
                        <div class="form-text text-muted">
                            Mindestens 6 Zeichen. Der Benutzer muss das Passwort bei der nächsten Anmeldung ändern.
                        </div>
                    </div>
                    <div class="d-flex justify-content-end">
                        <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal">Abbrechen</button>
                        <button type="submit" class="btn btn-warning">Passwort zurücksetzen</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Benutzer löschen Modal -->
<div class="modal fade" id="delete-user-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Benutzer löschen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Möchtest du den Benutzer <strong id="delete-username"></strong> wirklich löschen?</p>
                <p class="text-danger">
                    <i class="fas fa-exclamation-triangle"></i> 
                    Die vom Benutzer erstellten Fraktionen, Items und Materialien bleiben erhalten.
                </p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Abbrechen</button>
                <a href="#" id="confirm-delete-user" class="btn btn-danger">Löschen</a>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Benutzerrechte bearbeiten
    const editRightsBtns = document.querySelectorAll('.edit-rights-btn');
    if (editRightsBtns) {
        editRightsBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                const username = this.getAttribute('data-username');
                const canEdit = this.getAttribute('data-can-edit') === '1';
                
                document.getElementById('edit-user-id').value = userId;
                document.getElementById('edit-username').textContent = username;
                document.getElementById('edit_can_edit').checked = canEdit;
                
                const modal = new bootstrap.Modal(document.getElementById('edit-rights-modal'));
                modal.show();
            });
        });
    }
    
    // Passwort zurücksetzen
    const resetPasswordBtns = document.querySelectorAll('.reset-password-btn');
    if (resetPasswordBtns) {
        resetPasswordBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                const username = this.getAttribute('data-username');
                
                document.getElementById('reset-user-id').value = userId;
                document.getElementById('reset-username').textContent = username;
                document.getElementById('new_password').value = '';
                
                const modal = new bootstrap.Modal(document.getElementById('reset-password-modal'));
                modal.show();
            });
        });
    }
    
    // Benutzer löschen
    const deleteUserBtns = document.querySelectorAll('.delete-user');
    if (deleteUserBtns) {
        deleteUserBtns.forEach(function(btn) {
            btn.addEventListener('click', function() {
                const userId = this.getAttribute('data-id');
                const username = this.getAttribute('data-username');
                
                document.getElementById('delete-username').textContent = username;
                document.getElementById('confirm-delete-user').href = 'benutzer.php?delete=' + userId;
                
                const modal = new bootstrap.Modal(document.getElementById('delete-user-modal'));
                modal.show();
            });
        });
    }
});
</script>

<?php include 'includes/footer.php'; ?>