<?php
/**
 * Fraktionen Verwaltungsseite
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Fraktionen";
$message = '';
$messageType = '';

// Verarbeite das Löschen einer Fraktion
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Fraktionen zu löschen.';
        $messageType = 'danger';
    } else {
        $id = $_GET['delete'];
        if (deleteFraktion($id)) {
            $message = 'Fraktion erfolgreich gelöscht.';
            $messageType = 'success';
            logAktivität('fa-trash-alt', 'Fraktion gelöscht: ID ' . $id);
        } else {
            $message = 'Fehler beim Löschen der Fraktion.';
            $messageType = 'danger';
        }
    }
}

// Verarbeite das Formular zum Erstellen/Bearbeiten einer Fraktion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_fraktion'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Fraktionen zu bearbeiten.';
        $messageType = 'danger';
    } else {
        $fraktion = [
            'name' => trim($_POST['name']),
            'beschreibung' => trim($_POST['beschreibung'])
        ];
    
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // Bearbeiten einer bestehenden Fraktion
            $fraktion['id'] = $_POST['id'];
            if (updateFraktion($fraktion)) {
                $message = 'Fraktion erfolgreich aktualisiert.';
                $messageType = 'success';
                logAktivität('fa-edit', 'Fraktion aktualisiert: ' . $fraktion['name']);
            } else {
                $message = 'Fehler beim Aktualisieren der Fraktion.';
                $messageType = 'danger';
            }
        } else {
            // Erstellen einer neuen Fraktion
            if (createFraktion($fraktion)) {
                $message = 'Fraktion erfolgreich angelegt.';
                $messageType = 'success';
                logAktivität('fa-plus-circle', 'Fraktion erstellt: ' . $fraktion['name']);
            } else {
                $message = 'Fehler beim Anlegen der Fraktion.';
                $messageType = 'danger';
            }
        }
    }
}

// Lade alle Fraktionen
$fraktionen = loadFraktionen();

// Bearbeiten-Modus: Lade Fraktion zum Bearbeiten
$editMode = false;
$currentFraktion = [
    'id' => '',
    'name' => '',
    'beschreibung' => ''
];

if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Fraktionen zu bearbeiten.';
        $messageType = 'danger';
    } else {
        $editMode = true;
        $id = $_GET['edit'];
        
        foreach ($fraktionen as $fraktion) {
            if ($fraktion['id'] === $id) {
                $currentFraktion = $fraktion;
                break;
            }
        }
    }
}

// Erstellen-Modus
$createMode = isset($_GET['action']) && $_GET['action'] === 'new';

// Wenn Benutzer keine Bearbeitungsrechte hat, neue Erstellungen verbieten
if ($createMode && !canEdit()) {
    $message = 'Sie haben keine Berechtigung, um neue Fraktionen zu erstellen.';
    $messageType = 'danger';
    $createMode = false;
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?php echo $pageTitle; ?></h1>
        <a href="?action=new" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Neue Fraktion</a>
    </div>
    
    <?php if (!empty($message)): ?>
    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
        <?php echo $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($editMode || $createMode): ?>
    <div class="card bg-dark text-white mb-4">
        <div class="card-header">
            <h5><?php echo $editMode ? 'Fraktion bearbeiten' : 'Neue Fraktion anlegen'; ?></h5>
        </div>
        <div class="card-body">
            <form method="post" action="fraktionen.php">
                <?php if ($editMode): ?>
                <input type="hidden" name="id" value="<?php echo $currentFraktion['id']; ?>">
                <?php endif; ?>
                
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control bg-dark text-white" id="name" name="name" 
                           value="<?php echo htmlspecialchars($currentFraktion['name']); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="beschreibung" class="form-label">Beschreibung</label>
                    <textarea class="form-control bg-dark text-white" id="beschreibung" name="beschreibung" rows="3"><?php echo htmlspecialchars($currentFraktion['beschreibung']); ?></textarea>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button type="submit" name="submit_fraktion" class="btn btn-primary">Speichern</button>
                    <a href="fraktionen.php" class="btn btn-secondary">Abbrechen</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="card bg-dark text-white">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5>Fraktionsliste</h5>
                <div class="input-group w-50">
                    <span class="input-group-text bg-dark text-white border-secondary"><i class="fas fa-search"></i></span>
                    <input type="text" id="fraktionen-suche" class="form-control bg-dark text-white border-secondary" placeholder="Fraktion suchen...">
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (count($fraktionen) > 0): ?>
            <div class="table-responsive">
                <table class="table table-dark table-hover" id="fraktionen-tabelle">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Beschreibung</th>
                            <th>Zugewiesene Items</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($fraktionen as $fraktion): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($fraktion['name']); ?></td>
                            <td><?php echo htmlspecialchars($fraktion['beschreibung']); ?></td>
                            <td>
                                <?php
                                $zugewieseneItems = getItemsForFraktion($fraktion['id']);
                                $itemCount = count($zugewieseneItems);
                                echo $itemCount;
                                if ($itemCount > 0) {
                                    echo ' <button type="button" class="btn btn-sm btn-outline-info view-items" 
                                         data-id="' . $fraktion['id'] . '" 
                                         data-name="' . htmlspecialchars($fraktion['name']) . '">
                                         <i class="fas fa-eye"></i> Anzeigen
                                     </button>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php if (canEdit()): ?>
                                <div class="btn-group" role="group">
                                    <a href="?edit=<?php echo $fraktion['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-edit"></i> Bearbeiten
                                    </a>
                                    <button type="button" class="btn btn-sm btn-outline-danger delete-fraktion" 
                                            data-id="<?php echo $fraktion['id']; ?>" 
                                            data-name="<?php echo htmlspecialchars($fraktion['name']); ?>">
                                        <i class="fas fa-trash-alt"></i> Löschen
                                    </button>
                                </div>
                                <?php else: ?>
                                <span class="text-muted"><i class="fas fa-eye"></i> Nur Ansicht</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-center text-muted">Keine Fraktionen gefunden. Erstellen Sie eine neue Fraktion.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Lösch-Bestätigungsdialog -->
<div class="modal fade" id="delete-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Fraktion löschen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Sind Sie sicher, dass Sie die Fraktion <span id="delete-fraktion-name"></span> löschen möchten?</p>
                <p class="text-danger">Diese Aktion kann nicht rückgängig gemacht werden und entfernt alle Zuweisungen dieser Fraktion.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Abbrechen</button>
                <a href="#" id="confirm-delete" class="btn btn-danger">Löschen</a>
            </div>
        </div>
    </div>
</div>

<!-- Items-Anzeige-Dialog -->
<div class="modal fade" id="items-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Items der Fraktion: <span id="fraktion-name"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="fraktion-items-container">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Beschreibung</th>
                                    <th>Rezeptbestandteile</th>
                                    <th>Aktionen</th>
                                </tr>
                            </thead>
                            <tbody id="fraktion-items-list">
                                <!-- Wird dynamisch gefüllt -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Schließen</button>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
