<?php
/**
 * Materialien Verwaltungsseite
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Materialien";
$message = '';
$messageType = '';

// Verarbeite das Löschen eines Materials
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Materialien zu löschen.';
        $messageType = 'danger';
    } else {
        $id = $_GET['delete'];
        if (deleteMaterial($id)) {
            $message = 'Material erfolgreich gelöscht.';
            $messageType = 'success';
            logAktivität('fa-trash-alt', 'Material gelöscht: ID ' . $id);
        } else {
            $message = 'Fehler beim Löschen des Materials.';
            $messageType = 'danger';
        }
    }
}

// Verarbeite das Formular zum Erstellen/Bearbeiten eines Materials
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_material'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Materialien zu erstellen oder zu bearbeiten.';
        $messageType = 'danger';
    } else {
        $material = [
            'name' => trim($_POST['name']),
            'beschreibung' => trim($_POST['beschreibung']),
            'fraktion_id' => $_POST['fraktion_id']
        ];
        
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // Bearbeiten eines bestehenden Materials
            $material['id'] = $_POST['id'];
            if (updateMaterial($material)) {
                $message = 'Material erfolgreich aktualisiert.';
                $messageType = 'success';
                logAktivität('fa-edit', 'Material aktualisiert: ' . $material['name']);
            } else {
                $message = 'Fehler beim Aktualisieren des Materials.';
                $messageType = 'danger';
            }
        } else {
            // Erstellen eines neuen Materials
            if (createMaterial($material)) {
                $message = 'Material erfolgreich angelegt.';
                $messageType = 'success';
                logAktivität('fa-plus-circle', 'Material erstellt: ' . $material['name']);
            } else {
                $message = 'Fehler beim Anlegen des Materials.';
                $messageType = 'danger';
            }
        }
    }
}

// Lade alle Materialien und Fraktionen
$materialien = loadMaterialien();
$fraktionen = loadFraktionen();
$items = loadItems();

// Bearbeiten-Modus: Lade Material zum Bearbeiten
$editMode = false;
$currentMaterial = [
    'id' => '',
    'name' => '',
    'beschreibung' => '',
    'fraktion_id' => ''
];

if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Materialien zu bearbeiten.';
        $messageType = 'danger';
    } else {
        $editMode = true;
        $id = $_GET['edit'];
        
        foreach ($materialien as $material) {
            if ($material['id'] === $id) {
                $currentMaterial = $material;
                break;
            }
        }
    }
}

// Erstellen-Modus
$createMode = isset($_GET['action']) && $_GET['action'] === 'new';

// Wenn Benutzer keine Bearbeitungsrechte hat, neue Erstellungen verbieten
if ($createMode && !canEdit()) {
    $message = 'Sie haben keine Berechtigung, um neue Materialien zu erstellen.';
    $messageType = 'danger';
    $createMode = false;
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?php echo $pageTitle; ?></h1>
        <?php if (canEdit()): ?>
        <a href="?action=new" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Neues Material</a>
        <?php endif; ?>
    </div>
    
    <?php if (!empty($message)): ?>
    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
        <?php echo $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($editMode || $createMode): ?>
    <div class="card bg-dark text-white mb-4">
        <div class="card-header">
            <h5><?php echo $editMode ? 'Material bearbeiten' : 'Neues Material anlegen'; ?></h5>
        </div>
        <div class="card-body">
            <form method="post" action="materialien.php">
                <?php if ($editMode): ?>
                <input type="hidden" name="id" value="<?php echo $currentMaterial['id']; ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control bg-dark text-white" id="name" name="name" 
                               value="<?php echo htmlspecialchars($currentMaterial['name']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="fraktion_id" class="form-label">Fraktion</label>
                        <select class="form-select bg-dark text-white" id="fraktion_id" name="fraktion_id" required>
                            <option value="">Fraktion auswählen</option>
                            <?php foreach ($fraktionen as $fraktion): ?>
                            <option value="<?php echo $fraktion['id']; ?>" <?php if ($fraktion['id'] === $currentMaterial['fraktion_id']) echo 'selected'; ?>>
                                <?php echo htmlspecialchars($fraktion['name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="beschreibung" class="form-label">Beschreibung</label>
                    <textarea class="form-control bg-dark text-white" id="beschreibung" name="beschreibung" rows="3"><?php echo htmlspecialchars($currentMaterial['beschreibung']); ?></textarea>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button type="submit" name="submit_material" class="btn btn-primary">Speichern</button>
                    <a href="materialien.php" class="btn btn-secondary">Abbrechen</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="card bg-dark text-white">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5>Materialliste</h5>
                <div class="input-group w-50">
                    <span class="input-group-text bg-dark text-white border-secondary"><i class="fas fa-search"></i></span>
                    <input type="text" id="materialien-suche" class="form-control bg-dark text-white border-secondary" placeholder="Material suchen...">
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (count($materialien) > 0): ?>
            <div class="table-responsive">
                <table class="table table-dark table-hover" id="materialien-tabelle">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Fraktion</th>
                            <th>Verwendung in Rezepten</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($materialien as $material): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($material['name']); ?></td>
                            <td>
                                <?php 
                                $fraktionsName = "Nicht zugewiesen";
                                foreach ($fraktionen as $fraktion) {
                                    if ($fraktion['id'] === $material['fraktion_id']) {
                                        $fraktionsName = htmlspecialchars($fraktion['name']);
                                        break;
                                    }
                                }
                                echo $fraktionsName;
                                ?>
                            </td>
                            <td>
                                <?php
                                $verwendungenInRezepten = getVerwendungenInRezepten('material', $material['id'], $items);
                                $verwendungenCount = count($verwendungenInRezepten);
                                echo $verwendungenCount;
                                if ($verwendungenCount > 0) {
                                    echo ' <button type="button" class="btn btn-sm btn-outline-info view-material-details" 
                                         data-id="' . $material['id'] . '" 
                                         data-name="' . htmlspecialchars($material['name']) . '">
                                         <i class="fas fa-eye"></i> Details
                                     </button>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php if (canEdit()): ?>
                                <div class="btn-group" role="group">
                                    <a href="?edit=<?php echo $material['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-edit"></i> Bearbeiten
                                    </a>
                                    <button type="button" class="btn btn-sm btn-outline-danger delete-material" 
                                            data-id="<?php echo $material['id']; ?>" 
                                            data-name="<?php echo htmlspecialchars($material['name']); ?>">
                                        <i class="fas fa-trash-alt"></i> Löschen
                                    </button>
                                </div>
                                <?php else: ?>
                                <span class="text-muted"><i class="fas fa-eye"></i> Nur Ansicht</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-center text-muted">Keine Materialien gefunden. Erstellen Sie ein neues Material.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Lösch-Bestätigungsdialog -->
<div class="modal fade" id="delete-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Material löschen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Sind Sie sicher, dass Sie das Material <span id="delete-material-name"></span> löschen möchten?</p>
                <p class="text-danger">Diese Aktion kann nicht rückgängig gemacht werden. Wenn dieses Material in Rezepten verwendet wird, können Abhängigkeiten fehlerhaft werden.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Abbrechen</button>
                <a href="#" id="confirm-delete" class="btn btn-danger">Löschen</a>
            </div>
        </div>
    </div>
</div>

<!-- Material-Details-Dialog -->
<div class="modal fade" id="material-details-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Details: <span id="material-name"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Informationen</h6>
                        <div class="card bg-dark border-secondary">
                            <div class="card-body">
                                <p><strong>Fraktion:</strong> <span id="material-fraktion"></span></p>
                                <p><strong>Beschreibung:</strong> <span id="material-beschreibung"></span></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6><i class="fas fa-truck-loading"></i> Wird bezogen von</h6>
                        <div class="card bg-dark border-secondary">
                            <div class="card-body">
                                <div id="material-verwendung-container">
                                    <!-- Wird dynamisch gefüllt mit Konsumenten -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <?php if (canEdit()): ?>
                <a href="#" id="edit-material-link" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Bearbeiten
                </a>
                <?php endif; ?>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Schließen</button>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
