<?php
/**
 * Passwort-Reset-Seite für die Fraktionsverwaltung
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

// Wenn der Benutzer keinen Passwort-Reset benötigt und nicht selbst ändern möchte, leite zum Dashboard weiter
if (!isset($_SESSION['password_reset_required']) && !isset($_GET['change'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

// Passwort-Reset-Formular verarbeiten
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $currentPassword = isset($_POST['current_password']) ? $_POST['current_password'] : '';
    $newPassword = isset($_POST['new_password']) ? $_POST['new_password'] : '';
    $confirmPassword = isset($_POST['confirm_password']) ? $_POST['confirm_password'] : '';
    
    if (empty($currentPassword) || empty($newPassword) || empty($confirmPassword)) {
        $error = 'Bitte fülle alle Felder aus.';
    } elseif ($newPassword !== $confirmPassword) {
        $error = 'Die neuen Passwörter stimmen nicht überein.';
    } elseif (strlen($newPassword) < 6) {
        $error = 'Das neue Passwort muss mindestens 6 Zeichen lang sein.';
    } else {
        $user = getBenutzerById($_SESSION['user_id']);
        
        if ($user && password_verify($currentPassword, $user['password'])) {
            // Passwort aktualisieren
            $updated = updateBenutzer($user['id'], [
                'password' => password_hash($newPassword, PASSWORD_DEFAULT),
                'password_reset_required' => false
            ]);
            
            if ($updated) {
                // Entferne Passwort-Reset-Flag aus der Session
                unset($_SESSION['password_reset_required']);
                
                // Logge die Aktivität
                logAktivität('fa-key', $user['username'] . ' hat sein Passwort geändert.');
                
                $success = 'Dein Passwort wurde erfolgreich geändert.';
                
                // Weiterleitung nach 2 Sekunden
                header('refresh:2;url=dashboard.php');
            } else {
                $error = 'Fehler beim Aktualisieren des Passworts. Bitte versuche es erneut.';
            }
        } else {
            $error = 'Das aktuelle Passwort ist nicht korrekt.';
        }
    }
}

// Seiten-Header
$pageTitle = 'Passwort ändern';
include 'includes/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card bg-dark text-white">
                <div class="card-header">
                    <h4 class="mb-0">
                        <i class="fas fa-key"></i> Passwort ändern
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (isset($_SESSION['password_reset_required'])) : ?>
                    <div class="alert alert-warning">
                        <i class="fas fa-exclamation-triangle"></i> Du musst dein Passwort ändern, bevor du fortfahren kannst.
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($error)) : ?>
                    <div class="alert alert-danger">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)) : ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="post" action="password_reset.php<?php echo isset($_GET['change']) ? '?change=1' : ''; ?>">
                        <div class="mb-3">
                            <label for="current_password" class="form-label">Aktuelles Passwort</label>
                            <input type="password" class="form-control" id="current_password" name="current_password" required autofocus>
                        </div>
                        <div class="mb-3">
                            <label for="new_password" class="form-label">Neues Passwort</label>
                            <input type="password" class="form-control" id="new_password" name="new_password" required>
                            <div class="form-text text-muted">
                                Mindestens 6 Zeichen lang.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="confirm_password" class="form-label">Neues Passwort bestätigen</label>
                            <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                        </div>
                        <div class="d-flex justify-content-between">
                            <?php if (!isset($_SESSION['password_reset_required'])) : ?>
                            <a href="dashboard.php" class="btn btn-secondary">Abbrechen</a>
                            <?php endif; ?>
                            <button type="submit" class="btn btn-primary">Passwort ändern</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>