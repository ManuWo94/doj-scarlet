/**
 * Spezifisches Skript für die Produktionsrouten-Seite
 */
document.addEventListener('DOMContentLoaded', function() {
    // Event-Listener für Suche
    const routenSuche = document.getElementById('routen-suche');
    if (routenSuche) {
        routenSuche.addEventListener('keyup', function() {
            searchRouten();
        });
    }
    
    // Event-Listener für Routen-Detail-Buttons
    const detailButtons = document.querySelectorAll('.view-route-details');
    if (detailButtons) {
        detailButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const itemId = this.getAttribute('data-id');
                const itemName = this.getAttribute('data-name');
                
                showRouteDetails(itemId, itemName);
            });
        });
    }
});

/**
 * Durchsucht die Produktionsrouten
 */
function searchRouten() {
    const searchTerm = document.getElementById('routen-suche').value.toLowerCase();
    const routenItems = document.querySelectorAll('.routen-eintrag');
    
    routenItems.forEach(function(item) {
        const itemText = item.textContent.toLowerCase();
        if (itemText.includes(searchTerm)) {
            item.style.display = '';
        } else {
            item.style.display = 'none';
        }
    });
}

/**
 * Zeigt Details einer Produktionsroute in einem Modal an
 * @param {string} itemId - ID des Items
 * @param {string} itemName - Name des Items
 */
function showRouteDetails(itemId, itemName) {
    const modal = document.getElementById('route-details-modal');
    const nameElement = document.getElementById('route-name');
    const detailsContainer = document.getElementById('route-details-container');
    
    if (modal && nameElement && detailsContainer) {
        nameElement.textContent = itemName;
        detailsContainer.innerHTML = '<div class="text-center"><i class="fas fa-spinner fa-spin"></i> Lade Produktionsroute...</div>';
        
        // AJAX-Anfrage, um Routen-Details zu laden
        fetch('includes/ajax-handler.php?action=get_route_details&id=' + itemId)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.route) {
                    const route = data.route;
                    
                    // HTML für die Produktionsroute erstellen
                    let html = `
                        <div class="route-diagram">
                            <div class="route-item border-primary p-3 mb-3 rounded">
                                <h5 class="text-primary"><i class="fas fa-cubes"></i> ${route.name}</h5>
                                <p class="mb-1"><strong>Produziert von:</strong> <span class="badge bg-success">${route.fraktion}</span></p>
                                ${route.beschreibung ? `<p class="text-muted">${route.beschreibung}</p>` : ''}
                            </div>
                    `;
                    
                    // Gruppiere Komponenten nach Fraktionen
                    const komponentenNachFraktion = {};
                    
                    // Direkten Zutaten in Gruppen organisieren
                    route.zutaten.forEach(zutat => {
                        if (!komponentenNachFraktion[zutat.fraktion_id]) {
                            komponentenNachFraktion[zutat.fraktion_id] = {
                                name: zutat.fraktion,
                                items: []
                            };
                        }
                        komponentenNachFraktion[zutat.fraktion_id].items.push(zutat);
                    });
                    
                    // Zeige die Fraktionen mit ihren Komponenten an
                    html += `
                        <h5 class="mt-4 mb-3"><i class="fas fa-truck"></i> Bezieht von folgenden Fraktionen:</h5>
                    `;
                    
                    Object.keys(komponentenNachFraktion).forEach(fraktionId => {
                        const fraktion = komponentenNachFraktion[fraktionId];
                        
                        html += `
                            <div class="route-faction mb-4">
                                <h6 class="mt-3 mb-2">
                                    <span class="badge bg-primary">${fraktion.name}</span>
                                </h6>
                                <div class="route-components ms-4">
                        `;
                        
                        // Komponenten dieser Fraktion anzeigen
                        fraktion.items.forEach(zutat => {
                            html += `
                                <div class="route-component border-${zutat.fehlend ? 'danger' : 'success'} p-3 mb-2 rounded">
                                    <div class="d-flex justify-content-between align-items-center">
                                        <div>
                                            ${zutat.fehlend 
                                                ? '<i class="fas fa-exclamation-circle text-danger"></i>' 
                                                : '<i class="fas fa-check-circle text-success"></i>'
                                            }
                                            <strong>${zutat.name}</strong>
                                            <span class="badge bg-secondary ms-1">${zutat.menge}x</span>
                                        </div>
                                        <div>
                                            <span class="badge bg-info">${zutat.typ}</span>
                                        </div>
                                    </div>
                            `;
                            
                            // Unterkomponenten hinzufügen, falls vorhanden
                            if (zutat.unterkomponenten && zutat.unterkomponenten.length > 0) {
                                // Unterkomponenten nach Fraktion gruppieren
                                const unterkomponentenNachFraktion = {};
                                
                                zutat.unterkomponenten.forEach(unterkomponente => {
                                    if (!unterkomponentenNachFraktion[unterkomponente.fraktion_id]) {
                                        unterkomponentenNachFraktion[unterkomponente.fraktion_id] = {
                                            name: unterkomponente.fraktion,
                                            items: []
                                        };
                                    }
                                    unterkomponentenNachFraktion[unterkomponente.fraktion_id].items.push(unterkomponente);
                                });
                                
                                html += `
                                    <div class="mt-2">
                                        <p class="mb-1 text-muted"><i class="fas fa-level-down-alt"></i> Besteht aus:</p>
                                `;
                                
                                // Für jede Fraktion in den Unterkomponenten
                                Object.keys(unterkomponentenNachFraktion).forEach(unterfraktionId => {
                                    const unterfraktion = unterkomponentenNachFraktion[unterfraktionId];
                                    
                                    html += `
                                        <div class="mt-2 mb-2">
                                            <span class="badge bg-primary">${unterfraktion.name}</span>
                                            <div class="route-subcomponents ms-3">
                                    `;
                                    
                                    unterfraktion.items.forEach(unterkomponente => {
                                        html += `
                                            <div class="route-subcomponent border-${unterkomponente.fehlend ? 'danger' : 'success'} p-2 mb-1 rounded">
                                                <div class="d-flex justify-content-between align-items-center">
                                                    <div>
                                                        ${unterkomponente.fehlend 
                                                            ? '<i class="fas fa-exclamation-circle text-danger"></i>' 
                                                            : '<i class="fas fa-check-circle text-success"></i>'
                                                        }
                                                        <span>${unterkomponente.name}</span>
                                                        <span class="badge bg-secondary ms-1">${unterkomponente.menge}x</span>
                                                    </div>
                                                    <div>
                                                        <span class="badge bg-info">${unterkomponente.typ}</span>
                                                    </div>
                                                </div>
                                            </div>
                                        `;
                                    });
                                    
                                    html += `
                                            </div>
                                        </div>
                                    `;
                                });
                                
                                html += `</div>`;
                            }
                            
                            html += `</div>`;
                        });
                        
                        html += `
                                </div>
                            </div>
                        `;
                    });
                    
                    html += `
                            </div>
                        </div>
                    `;
                    
                    detailsContainer.innerHTML = html;
                } else {
                    detailsContainer.innerHTML = '<div class="alert alert-danger">Fehler beim Laden der Routendetails.</div>';
                }
            })
            .catch(error => {
                console.error('Fehler beim Laden der Routendetails:', error);
                detailsContainer.innerHTML = '<div class="alert alert-danger">Fehler beim Laden der Routendetails.</div>';
            });
        
        // Modal anzeigen
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }
}
