/**
 * Spezifisches Skript für die Import/Export-Seite
 */
document.addEventListener('DOMContentLoaded', function() {
    // Event-Listener für "In Zwischenablage kopieren"
    const copyButton = document.getElementById('copy-export');
    if (copyButton) {
        copyButton.addEventListener('click', function() {
            const exportText = document.getElementById('exportText').value;
            copyToClipboard(exportText, this);
        });
    }
    
    // Event-Listener für "Als Datei herunterladen"
    const downloadButton = document.getElementById('download-export');
    if (downloadButton) {
        downloadButton.addEventListener('click', function() {
            const exportText = document.getElementById('exportText').value;
            const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
            const filename = 'fraktionsverwaltung-export-' + timestamp + '.txt';
            saveAsFile(exportText, filename);
        });
    }
    
    // Event-Listener für "Alle Fraktionen auswählen/abwählen"
    const checkAllFraktionen = document.getElementById('check-all-fraktionen');
    if (checkAllFraktionen) {
        checkAllFraktionen.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.fraktion-checkbox');
            checkboxes.forEach(function(checkbox) {
                checkbox.checked = checkAllFraktionen.checked;
            });
        });
    }
    
    // Event-Listener für "Alle Materialien auswählen/abwählen"
    const checkAllMaterialien = document.getElementById('check-all-materialien');
    if (checkAllMaterialien) {
        checkAllMaterialien.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.material-checkbox');
            checkboxes.forEach(function(checkbox) {
                checkbox.checked = checkAllMaterialien.checked;
            });
        });
    }
    
    // Event-Listener für "Alle Items auswählen/abwählen"
    const checkAllItems = document.getElementById('check-all-items');
    if (checkAllItems) {
        checkAllItems.addEventListener('change', function() {
            const checkboxes = document.querySelectorAll('.item-checkbox');
            checkboxes.forEach(function(checkbox) {
                checkbox.checked = checkAllItems.checked;
            });
        });
    }
});
