/**
 * Spezifisches Skript für die Fraktionen-Seite
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialisiere Tabellen-Suche
    initTableSearch('fraktionen-suche', 'fraktionen-tabelle');
    
    // Event-Listener für Lösch-Buttons
    const deleteButtons = document.querySelectorAll('.delete-fraktion');
    if (deleteButtons) {
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const deleteUrl = 'fraktionen.php?delete=' + id;
                
                showDeleteConfirmation('delete-modal', 'delete-fraktion-name', 'confirm-delete', name, deleteUrl);
            });
        });
    }
    
    // Event-Listener für Items-Anzeige-Buttons
    const viewItemsButtons = document.querySelectorAll('.view-items');
    if (viewItemsButtons) {
        viewItemsButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const fraktionId = this.getAttribute('data-id');
                const fraktionName = this.getAttribute('data-name');
                
                showFraktionItems(fraktionId, fraktionName);
            });
        });
    }
});

/**
 * Zeigt Items einer Fraktion in einem Modal an
 * @param {string} fraktionId - ID der Fraktion
 * @param {string} fraktionName - Name der Fraktion
 */
function showFraktionItems(fraktionId, fraktionName) {
    const modal = document.getElementById('items-modal');
    const nameElement = document.getElementById('fraktion-name');
    const itemsListElement = document.getElementById('fraktion-items-list');
    
    if (modal && nameElement && itemsListElement) {
        nameElement.textContent = fraktionName;
        itemsListElement.innerHTML = '<tr><td colspan="4" class="text-center"><i class="fas fa-spinner fa-spin"></i> Lade Items...</td></tr>';
        
        // AJAX-Anfrage, um Items zu laden
        fetch('includes/ajax-handler.php?action=get_fraktion_items&id=' + fraktionId)
            .then(response => response.json())
            .then(data => {
                itemsListElement.innerHTML = '';
                
                if (data.items && data.items.length > 0) {
                    data.items.forEach(item => {
                        let rezeptHtml = 'Keine Zutaten';
                        if (item.rezept && item.rezept.length > 0) {
                            rezeptHtml = '<ul class="mb-0 ps-3">';
                            item.rezept.forEach(bestandteil => {
                                rezeptHtml += `<li>${bestandteil.name} (${bestandteil.menge}x)</li>`;
                            });
                            rezeptHtml += '</ul>';
                        }
                        
                        const row = `
                            <tr>
                                <td>${item.name}</td>
                                <td>${item.beschreibung || '-'}</td>
                                <td>${rezeptHtml}</td>
                                <td>
                                    <a href="items.php?edit=${item.id}" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-edit"></i> Bearbeiten
                                    </a>
                                </td>
                            </tr>
                        `;
                        
                        itemsListElement.innerHTML += row;
                    });
                } else {
                    itemsListElement.innerHTML = '<tr><td colspan="4" class="text-center text-muted">Keine Items für diese Fraktion gefunden.</td></tr>';
                }
            })
            .catch(error => {
                console.error('Fehler beim Laden der Items:', error);
                itemsListElement.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Fehler beim Laden der Items.</td></tr>';
            });
        
        // Modal anzeigen
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }
}
