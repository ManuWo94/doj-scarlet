/**
 * Hauptskript für die Fraktionsverwaltung
 */

// Initialisiere beim Laden der Seite
document.addEventListener('DOMContentLoaded', function() {
    // Initialisiere Bootstrap Tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Initialisiere Bootstrap Popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });
    
    // Initialisiere Select2 für alle Dropdown-Menüs
    $('.form-select').each(function() {
        $(this).select2({
            theme: 'bootstrap-5',
            width: '100%',
            dropdownParent: $(this).parent()
        });
    });
    
    // Alerts automatisch ausblenden nach 5 Sekunden
    setTimeout(function() {
        $('.alert').alert('close');
    }, 5000);
});

/**
 * Generische Suchfunktion für Tabellen
 * @param {string} inputId - ID des Sucheingabefelds
 * @param {string} tableId - ID der zu durchsuchenden Tabelle
 */
function initTableSearch(inputId, tableId) {
    const searchInput = document.getElementById(inputId);
    const table = document.getElementById(tableId);
    
    if (searchInput && table) {
        searchInput.addEventListener('keyup', function() {
            const searchTerm = this.value.toLowerCase();
            const rows = table.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
            
            for (let i = 0; i < rows.length; i++) {
                let found = false;
                const cells = rows[i].getElementsByTagName('td');
                
                for (let j = 0; j < cells.length; j++) {
                    const cellText = cells[j].textContent || cells[j].innerText;
                    
                    if (cellText.toLowerCase().indexOf(searchTerm) > -1) {
                        found = true;
                        break;
                    }
                }
                
                rows[i].style.display = found ? '' : 'none';
            }
        });
    }
}

/**
 * Zeigt einen Lösch-Bestätigungsdialog an
 * @param {string} modalId - ID des Modal-Dialogs
 * @param {string} nameElementId - ID des Elements, in das der Name eingefügt wird
 * @param {string} confirmButtonId - ID des Bestätigungsbuttons
 * @param {string} name - Der anzuzeigende Name
 * @param {string} deleteUrl - Die URL zum Löschen
 */
function showDeleteConfirmation(modalId, nameElementId, confirmButtonId, name, deleteUrl) {
    const modal = document.getElementById(modalId);
    const nameElement = document.getElementById(nameElementId);
    const confirmButton = document.getElementById(confirmButtonId);
    
    if (modal && nameElement && confirmButton) {
        nameElement.textContent = name;
        confirmButton.href = deleteUrl;
        
        // Modal anzeigen
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }
}

/**
 * Kopiert einen Text in die Zwischenablage
 * @param {string} text - Der zu kopierende Text
 * @param {HTMLElement} button - Der Button, der geklickt wurde
 */
function copyToClipboard(text, button) {
    navigator.clipboard.writeText(text).then(function() {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i> Kopiert!';
        
        setTimeout(function() {
            button.innerHTML = originalText;
        }, 2000);
    }, function() {
        alert('Fehler beim Kopieren in die Zwischenablage. Bitte manuell kopieren.');
    });
}

/**
 * Speichert einen Text als Datei
 * @param {string} text - Der zu speichernde Text
 * @param {string} filename - Der Dateiname
 */
function saveAsFile(text, filename) {
    const blob = new Blob([text], {type: 'text/plain'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    
    a.href = url;
    a.download = filename;
    a.click();
    
    URL.revokeObjectURL(url);
}
