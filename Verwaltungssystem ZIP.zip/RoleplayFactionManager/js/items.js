/**
 * Spezifisches Skript für die Items-Seite
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialisiere Tabellen-Suche
    initTableSearch('items-suche', 'items-tabelle');
    
    // Initialisiere Select2 für die Rezept-Material-Auswahl
    $('.rezept-material-select').each(function() {
        $(this).select2({
            theme: 'bootstrap-5',
            width: '100%',
            dropdownParent: $(this).parent()
        });
    });
    
    // Event-Listener für Lösch-Buttons
    const deleteButtons = document.querySelectorAll('.delete-item');
    if (deleteButtons) {
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const deleteUrl = 'items.php?delete=' + id;
                
                showDeleteConfirmation('delete-modal', 'delete-item-name', 'confirm-delete', name, deleteUrl);
            });
        });
    }
    
    // Event-Listener für Details-Buttons
    const detailButtons = document.querySelectorAll('.view-item-details');
    if (detailButtons) {
        detailButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const itemId = this.getAttribute('data-id');
                const itemName = this.getAttribute('data-name');
                
                showItemDetails(itemId, itemName);
            });
        });
    }
    
    // Event-Listener für Material hinzufügen Button
    const addMaterialButton = document.getElementById('add-material');
    if (addMaterialButton) {
        addMaterialButton.addEventListener('click', function() {
            addRezeptZeile();
        });
    }
    
    // Event-Listener für Material entfernen Buttons
    setupRemoveMaterialButtons();
    
    // Bei Formular-Submit prüfen
    const itemForm = document.getElementById('item-form');
    if (itemForm) {
        itemForm.addEventListener('submit', function(e) {
            const rezeptZeilen = document.querySelectorAll('.rezept-zeile');
            if (rezeptZeilen.length === 0) {
                e.preventDefault();
                alert('Bitte fügen Sie mindestens ein Material oder Item zum Rezept hinzu.');
            }
        });
    }
});

/**
 * Zeigt Details eines Items in einem Modal an
 * @param {string} itemId - ID des Items
 * @param {string} itemName - Name des Items
 */
function showItemDetails(itemId, itemName) {
    const modal = document.getElementById('item-details-modal');
    const nameElement = document.getElementById('item-name');
    const fraktionElement = document.getElementById('item-fraktion');
    const beschreibungElement = document.getElementById('item-beschreibung');
    const rezeptListElement = document.getElementById('rezept-container');
    const verwendungElement = document.getElementById('item-verwendung-container');
    const beziehtVonElement = document.getElementById('item-bezieht-container');
    const editLink = document.getElementById('edit-item-link');
    
    if (modal && nameElement && fraktionElement && beschreibungElement && rezeptListElement && verwendungElement && beziehtVonElement && editLink) {
        nameElement.textContent = itemName;
        rezeptListElement.innerHTML = '<tr><td colspan="3" class="text-center"><i class="fas fa-spinner fa-spin"></i> Lade Daten...</td></tr>';
        verwendungElement.innerHTML = '<p class="text-center"><i class="fas fa-spinner fa-spin"></i> Lade Daten...</p>';
        beziehtVonElement.innerHTML = '<p class="text-center"><i class="fas fa-spinner fa-spin"></i> Lade Daten...</p>';
        
        // AJAX-Anfrage, um Item-Details zu laden
        fetch('includes/ajax-handler.php?action=get_item_details&id=' + itemId)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.item) {
                    const item = data.item;
                    
                    // Update Informationen
                    if (data.produzent) {
                        fraktionElement.innerHTML = `<span class="badge bg-success">${data.produzent.name}</span> (Hersteller)`;
                    } else {
                        fraktionElement.textContent = item.fraktion || 'Keine Fraktion';
                    }
                    beschreibungElement.textContent = item.beschreibung || 'Keine Beschreibung';
                    editLink.href = 'items.php?edit=' + itemId;
                    
                    // Rezept-Tabelle aktualisieren
                    rezeptListElement.innerHTML = '';
                    if (item.rezept && item.rezept.length > 0) {
                        item.rezept.forEach(bestandteil => {
                            const row = `
                                <tr>
                                    <td>${bestandteil.name}</td>
                                    <td>${bestandteil.typ === 'material' ? 'Material' : 'Item'}</td>
                                    <td>${bestandteil.menge}x</td>
                                </tr>
                            `;
                            rezeptListElement.innerHTML += row;
                        });
                    } else {
                        rezeptListElement.innerHTML = '<tr><td colspan="3" class="text-center text-muted">Keine Rezeptbestandteile vorhanden.</td></tr>';
                    }
                    
                    // Konsumenten aktualisieren (Wer bezieht das Item?)
                    verwendungElement.innerHTML = '';
                    if (data.konsumenten && data.konsumenten.length > 0) {
                        // Gruppiere nach Fraktionen
                        const konsumentenNachFraktion = {};
                        
                        data.konsumenten.forEach(konsument => {
                            if (!konsumentenNachFraktion[konsument.fraktion_id]) {
                                konsumentenNachFraktion[konsument.fraktion_id] = {
                                    name: konsument.fraktion_name,
                                    items: []
                                };
                            }
                            konsumentenNachFraktion[konsument.fraktion_id].items.push(konsument);
                        });
                        
                        const verwendungenHTML = `
                            <div class="alert alert-success">
                                <h6 class="mb-2"><i class="fas fa-truck-loading"></i> Folgende Fraktionen beziehen dieses Item:</h6>
                                <ul class="mb-0 ps-3">
                                    ${Object.values(konsumentenNachFraktion).map(fraktion => `
                                        <li class="mb-2">
                                            <span class="badge bg-primary">${fraktion.name}</span>
                                            <ul class="mt-1">
                                                ${fraktion.items.map(item => `
                                                    <li>${item.menge}x für ${item.item_name}</li>
                                                `).join('')}
                                            </ul>
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                        `;
                        verwendungElement.innerHTML = verwendungenHTML;
                    } else {
                        verwendungElement.innerHTML = '<p class="text-muted mb-0">Dieses Item wird von keiner anderen Fraktion bezogen.</p>';
                    }
                    
                    // Lieferanten aktualisieren (Von wem bezieht man Komponenten?)
                    beziehtVonElement.innerHTML = '';
                    if (data.bezieht_von && data.bezieht_von.length > 0) {
                        // Gruppiere nach Fraktionen
                        const lieferantenNachFraktion = {};
                        
                        data.bezieht_von.forEach(lieferant => {
                            if (!lieferantenNachFraktion[lieferant.fraktion_id]) {
                                lieferantenNachFraktion[lieferant.fraktion_id] = {
                                    name: lieferant.fraktion_name,
                                    items: []
                                };
                            }
                            lieferantenNachFraktion[lieferant.fraktion_id].items.push(lieferant);
                        });
                        
                        const beziehtVonHTML = `
                            <div class="alert alert-info">
                                <h6 class="mb-2"><i class="fas fa-truck"></i> Komponenten werden bezogen von:</h6>
                                <ul class="mb-0 ps-3">
                                    ${Object.values(lieferantenNachFraktion).map(fraktion => `
                                        <li class="mb-2">
                                            <span class="badge bg-primary">${fraktion.name}</span>
                                            <ul class="mt-1">
                                                ${fraktion.items.map(item => `
                                                    <li>${item.menge}x ${item.name} (${item.typ === 'material' ? 'Material' : 'Item'})</li>
                                                `).join('')}
                                            </ul>
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                        `;
                        beziehtVonElement.innerHTML = beziehtVonHTML;
                    } else {
                        beziehtVonElement.innerHTML = '<p class="text-muted mb-0">Für dieses Item werden keine Komponenten von anderen Fraktionen bezogen.</p>';
                    }
                } else {
                    rezeptListElement.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Fehler beim Laden der Item-Details.</td></tr>';
                    verwendungElement.innerHTML = '<p class="text-danger">Fehler beim Laden der Verwendungen.</p>';
                    beziehtVonElement.innerHTML = '<p class="text-danger">Fehler beim Laden der Lieferanten-Informationen.</p>';
                }
            })
            .catch(error => {
                console.error('Fehler beim Laden der Item-Details:', error);
                rezeptListElement.innerHTML = '<tr><td colspan="3" class="text-center text-danger">Fehler beim Laden der Item-Details.</td></tr>';
                verwendungElement.innerHTML = '<p class="text-danger">Fehler beim Laden der Verwendungen.</p>';
                beziehtVonElement.innerHTML = '<p class="text-danger">Fehler beim Laden der Lieferanten-Informationen.</p>';
            });
        
        // Modal anzeigen
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }
}

/**
 * Fügt eine neue Rezept-Zeile hinzu
 */
function addRezeptZeile() {
    const rezeptContainer = document.getElementById('rezept-container');
    const template = document.getElementById('rezept-zeile-template');
    
    if (rezeptContainer && template) {
        const clone = document.importNode(template.content, true);
        rezeptContainer.appendChild(clone);
        
        // Initialisiere Select2 für das neue Dropdown
        $('.rezept-zeile:last-child .rezept-material-select').select2({
            theme: 'bootstrap-5',
            width: '100%',
            dropdownParent: $('.rezept-zeile:last-child .rezept-material-select').parent()
        });
        
        // Event-Listener für neue Entfernen-Buttons
        setupRemoveMaterialButtons();
    }
}

/**
 * Richtet Event-Listener für Material entfernen Buttons ein
 */
function setupRemoveMaterialButtons() {
    const removeButtons = document.querySelectorAll('.entferne-material');
    removeButtons.forEach(function(button) {
        // Event-Listener nur einmal hinzufügen
        if (!button.hasAttribute('data-initialized')) {
            button.setAttribute('data-initialized', 'true');
            
            button.addEventListener('click', function() {
                const rezeptZeile = this.closest('.rezept-zeile');
                const rezeptContainer = document.getElementById('rezept-container');
                
                // Wenn es die letzte Zeile ist, nicht entfernen
                if (rezeptContainer.children.length > 1) {
                    rezeptZeile.remove();
                } else {
                    alert('Mindestens ein Material/Item muss im Rezept bleiben.');
                }
            });
        }
    });
}
