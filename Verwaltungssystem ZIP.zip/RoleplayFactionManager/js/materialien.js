/**
 * Spezifisches Skript für die Materialien-Seite
 */
document.addEventListener('DOMContentLoaded', function() {
    // Initialisiere Tabellen-Suche
    initTableSearch('materialien-suche', 'materialien-tabelle');
    
    // Event-Listener für Lösch-Buttons
    const deleteButtons = document.querySelectorAll('.delete-material');
    if (deleteButtons) {
        deleteButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const id = this.getAttribute('data-id');
                const name = this.getAttribute('data-name');
                const deleteUrl = 'materialien.php?delete=' + id;
                
                showDeleteConfirmation('delete-modal', 'delete-material-name', 'confirm-delete', name, deleteUrl);
            });
        });
    }
    
    // Event-Listener für Details-Buttons
    const detailButtons = document.querySelectorAll('.view-material-details');
    if (detailButtons) {
        detailButtons.forEach(function(button) {
            button.addEventListener('click', function() {
                const materialId = this.getAttribute('data-id');
                const materialName = this.getAttribute('data-name');
                
                showMaterialDetails(materialId, materialName);
            });
        });
    }
});

/**
 * Zeigt Details eines Materials in einem Modal an
 * @param {string} materialId - ID des Materials
 * @param {string} materialName - Name des Materials
 */
function showMaterialDetails(materialId, materialName) {
    const modal = document.getElementById('material-details-modal');
    const nameElement = document.getElementById('material-name');
    const fraktionElement = document.getElementById('material-fraktion');
    const beschreibungElement = document.getElementById('material-beschreibung');
    const verwendungElement = document.getElementById('material-verwendung-container');
    const editLink = document.getElementById('edit-material-link');
    
    if (modal && nameElement && fraktionElement && beschreibungElement && verwendungElement && editLink) {
        nameElement.textContent = materialName;
        verwendungElement.innerHTML = '<p class="text-center"><i class="fas fa-spinner fa-spin"></i> Lade Daten...</p>';
        
        // AJAX-Anfrage, um Material-Details zu laden
        fetch('includes/ajax-handler.php?action=get_material_details&id=' + materialId)
            .then(response => response.json())
            .then(data => {
                if (data.success && data.material) {
                    const material = data.material;
                    
                    // Update Informationen
                    if (data.produzent) {
                        fraktionElement.innerHTML = `<span class="badge bg-success">${data.produzent.name}</span> (Hersteller)`;
                    } else {
                        fraktionElement.textContent = material.fraktion || 'Keine Fraktion';
                    }
                    beschreibungElement.textContent = material.beschreibung || 'Keine Beschreibung';
                    editLink.href = 'materialien.php?edit=' + materialId;
                    
                    // Konsumenten aktualisieren (wer verwendet das Material)
                    verwendungElement.innerHTML = '';
                    if (data.konsumenten && data.konsumenten.length > 0) {
                        const verwendungenHTML = `
                            <div class="alert alert-success">
                                <h6 class="mb-2"><i class="fas fa-truck-loading"></i> Folgende Fraktionen beziehen dieses Material:</h6>
                                <ul class="mb-0 ps-3">
                                    ${Object.values(data.konsumentenNachFraktion || {}).map(fraktion => `
                                        <li class="mb-2">
                                            <span class="badge bg-primary">${fraktion.name}</span>
                                            <ul class="mt-1">
                                                ${fraktion.items.map(item => `
                                                    <li>${item.menge}x für ${item.item_name}</li>
                                                `).join('')}
                                            </ul>
                                        </li>
                                    `).join('')}
                                </ul>
                            </div>
                        `;
                        verwendungElement.innerHTML = verwendungenHTML;
                    } else if (material.verwendet_in && material.verwendet_in.length > 0) {
                        // Fallback auf das alte Format, falls die neue Struktur nicht verfügbar ist
                        const verwendungenList = document.createElement('ul');
                        verwendungenList.className = 'mb-0 ps-3';
                        
                        // Gruppiere Verwendungen nach Fraktion
                        const nachFraktionGruppiert = {};
                        
                        material.verwendet_in.forEach(verwendung => {
                            if (!nachFraktionGruppiert[verwendung.fraktion_id]) {
                                nachFraktionGruppiert[verwendung.fraktion_id] = {
                                    name: verwendung.fraktion,
                                    items: []
                                };
                            }
                            nachFraktionGruppiert[verwendung.fraktion_id].items.push(verwendung);
                        });
                        
                        // Erstelle die Liste der Verwendungen gruppiert nach Fraktionen
                        Object.values(nachFraktionGruppiert).forEach(fraktionsGruppe => {
                            const fraktionsLi = document.createElement('li');
                            fraktionsLi.className = 'mb-2';
                            
                            const fraktionsBadge = document.createElement('span');
                            fraktionsBadge.className = 'badge bg-primary';
                            fraktionsBadge.textContent = fraktionsGruppe.name;
                            fraktionsLi.appendChild(fraktionsBadge);
                            
                            const itemsList = document.createElement('ul');
                            itemsList.className = 'mt-1 ps-3';
                            
                            fraktionsGruppe.items.forEach(item => {
                                const itemLi = document.createElement('li');
                                itemLi.textContent = item.name;
                                itemsList.appendChild(itemLi);
                            });
                            
                            fraktionsLi.appendChild(itemsList);
                            verwendungenList.appendChild(fraktionsLi);
                        });
                        
                        verwendungElement.appendChild(verwendungenList);
                    } else {
                        verwendungElement.innerHTML = '<p class="text-muted mb-0">Dieses Material wird von keiner Fraktion bezogen.</p>';
                    }
                } else {
                    verwendungElement.innerHTML = '<p class="text-danger">Fehler beim Laden der Material-Details.</p>';
                }
            })
            .catch(error => {
                console.error('Fehler beim Laden der Material-Details:', error);
                verwendungElement.innerHTML = '<p class="text-danger">Fehler beim Laden der Material-Details.</p>';
            });
        
        // Modal anzeigen
        const bsModal = new bootstrap.Modal(modal);
        bsModal.show();
    }
}
