<?php
/**
 * Dashboard Seite - Übersicht der Fraktionsverwaltung
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Dashboard";

// Lade alle benötigten Daten
$fraktionen = loadFraktionen();
$items = loadItems();
$materialien = loadMaterialien();

// Berechne Statistiken
$anzahlFraktionen = count($fraktionen);
$anzahlItems = count($items);
$anzahlMaterialien = count($materialien);

// Überprüfe auf fehlende Produktionsrouten
$fehlendeRouten = prüfeFehlendeProduktionsrouten($fraktionen, $items, $materialien);
$anzahlFehlendeRouten = count($fehlendeRouten);

include 'includes/header.php';
?>

<div class="container py-4">
    <h1 class="mb-4">Dashboard</h1>
    
    <div class="row">
        <div class="col-md-3 mb-4">
            <div class="card bg-dark text-white border-primary">
                <div class="card-body">
                    <h5 class="card-title">Fraktionen</h5>
                    <p class="card-text display-4"><?php echo $anzahlFraktionen; ?></p>
                    <a href="fraktionen.php" class="btn btn-outline-light btn-sm">Verwalten</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-dark text-white border-success">
                <div class="card-body">
                    <h5 class="card-title">Items</h5>
                    <p class="card-text display-4"><?php echo $anzahlItems; ?></p>
                    <a href="items.php" class="btn btn-outline-light btn-sm">Verwalten</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-dark text-white border-info">
                <div class="card-body">
                    <h5 class="card-title">Materialien</h5>
                    <p class="card-text display-4"><?php echo $anzahlMaterialien; ?></p>
                    <a href="materialien.php" class="btn btn-outline-light btn-sm">Verwalten</a>
                </div>
            </div>
        </div>
        <div class="col-md-3 mb-4">
            <div class="card bg-dark text-white border-danger">
                <div class="card-body">
                    <h5 class="card-title">Fehlende Routen</h5>
                    <p class="card-text display-4"><?php echo $anzahlFehlendeRouten; ?></p>
                    <a href="produktionsrouten.php" class="btn btn-outline-light btn-sm">Überprüfen</a>
                </div>
            </div>
        </div>
    </div>
    
    <?php if ($anzahlFehlendeRouten > 0): ?>
    <div class="row mt-4">
        <div class="col-12">
            <div class="card bg-dark text-white border-danger">
                <div class="card-header bg-danger text-white">
                    <h5><i class="fas fa-exclamation-triangle"></i> Fehlende Produktionsrouten</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-dark table-hover">
                            <thead>
                                <tr>
                                    <th>Item/Material</th>
                                    <th>Benötigt von</th>
                                    <th>Aktionen</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($fehlendeRouten as $route): ?>
                                <tr>
                                    <td class="text-danger">
                                        <i class="fas fa-exclamation-circle"></i> 
                                        <?php echo htmlspecialchars($route['name']); ?>
                                    </td>
                                    <td><?php echo htmlspecialchars($route['benötigtVon']); ?></td>
                                    <td>
                                        <?php if($route['typ'] === 'item'): ?>
                                            <a href="items.php?edit=<?php echo $route['id']; ?>" class="btn btn-sm btn-outline-primary">Bearbeiten</a>
                                        <?php else: ?>
                                            <a href="materialien.php?edit=<?php echo $route['id']; ?>" class="btn btn-sm btn-outline-primary">Bearbeiten</a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    
    <div class="row mt-4">
        <div class="col-md-6 mb-4">
            <div class="card bg-dark text-white">
                <div class="card-header">
                    <h5>Schnellzugriff</h5>
                </div>
                <div class="card-body">
                    <div class="list-group bg-dark">
                        <a href="fraktionen.php?action=new" class="list-group-item list-group-item-action bg-dark text-white border-secondary">
                            <i class="fas fa-plus-circle"></i> Neue Fraktion anlegen
                        </a>
                        <a href="items.php?action=new" class="list-group-item list-group-item-action bg-dark text-white border-secondary">
                            <i class="fas fa-plus-circle"></i> Neues Item mit Rezept anlegen
                        </a>
                        <a href="materialien.php?action=new" class="list-group-item list-group-item-action bg-dark text-white border-secondary">
                            <i class="fas fa-plus-circle"></i> Neues Material anlegen
                        </a>
                        <a href="produktionsrouten.php" class="list-group-item list-group-item-action bg-dark text-white border-secondary">
                            <i class="fas fa-route"></i> Produktionsrouten überprüfen
                        </a>
                        <a href="import-export.php" class="list-group-item list-group-item-action bg-dark text-white border-secondary">
                            <i class="fas fa-file-export"></i> Import/Export
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card bg-dark text-white">
                <div class="card-header">
                    <h5>Letzte Aktivitäten</h5>
                </div>
                <div class="card-body">
                    <?php $aktivitäten = getAktivitäten(5); ?>
                    <?php if (count($aktivitäten) > 0): ?>
                        <ul class="list-group bg-dark">
                            <?php foreach($aktivitäten as $aktivität): ?>
                            <li class="list-group-item bg-dark text-white border-secondary">
                                <i class="fas <?php echo $aktivität['icon']; ?>"></i>
                                <?php echo htmlspecialchars($aktivität['text']); ?>
                                <small class="text-muted d-block"><?php echo $aktivität['zeit']; ?></small>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php else: ?>
                        <p class="text-muted">Keine Aktivitäten gefunden.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
