<?php
/**
 * Items Verwaltungsseite
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Items";
$message = '';
$messageType = '';

// Verarbeite das Löschen eines Items
if (isset($_GET['delete']) && !empty($_GET['delete'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Items zu löschen.';
        $messageType = 'danger';
    } else {
        $id = $_GET['delete'];
        if (deleteItem($id)) {
            $message = 'Item erfolgreich gelöscht.';
            $messageType = 'success';
            logAktivität('fa-trash-alt', 'Item gelöscht: ID ' . $id);
        } else {
            $message = 'Fehler beim Löschen des Items.';
            $messageType = 'danger';
        }
    }
}

// Verarbeite das Formular zum Erstellen/Bearbeiten eines Items
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_item'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Items zu erstellen oder zu bearbeiten.';
        $messageType = 'danger';
    } else {
        $rezeptMaterialien = [];
        
        // Verarbeite die Rezeptbestandteile
        if (isset($_POST['material_id']) && isset($_POST['menge'])) {
            $materialIds = $_POST['material_id'];
            $mengen = $_POST['menge'];
            
            for ($i = 0; $i < count($materialIds); $i++) {
                if (!empty($materialIds[$i]) && !empty($mengen[$i])) {
                    $rezeptMaterialien[] = [
                        'id' => $materialIds[$i],
                        'menge' => intval($mengen[$i])
                    ];
                }
            }
        }
        
        $item = [
            'name' => trim($_POST['name']),
            'beschreibung' => trim($_POST['beschreibung']),
            'fraktion_id' => $_POST['fraktion_id'],
            'rezept' => $rezeptMaterialien
        ];
    
        if (isset($_POST['id']) && !empty($_POST['id'])) {
            // Bearbeiten eines bestehenden Items
            $item['id'] = $_POST['id'];
            if (updateItem($item)) {
                $message = 'Item erfolgreich aktualisiert.';
                $messageType = 'success';
                logAktivität('fa-edit', 'Item aktualisiert: ' . $item['name']);
            } else {
                $message = 'Fehler beim Aktualisieren des Items.';
                $messageType = 'danger';
            }
        } else {
            // Erstellen eines neuen Items
            if (createItem($item)) {
                $message = 'Item erfolgreich angelegt.';
                $messageType = 'success';
                logAktivität('fa-plus-circle', 'Item erstellt: ' . $item['name']);
            } else {
                $message = 'Fehler beim Anlegen des Items.';
                $messageType = 'danger';
            }
        }
    }
}

// Lade alle Items, Materialien und Fraktionen
$items = loadItems();
$materialien = loadMaterialien();
$fraktionen = loadFraktionen();

// Bearbeiten-Modus: Lade Item zum Bearbeiten
$editMode = false;
$currentItem = [
    'id' => '',
    'name' => '',
    'beschreibung' => '',
    'fraktion_id' => '',
    'rezept' => []
];

if (isset($_GET['edit']) && !empty($_GET['edit'])) {
    // Prüfe, ob der Benutzer Bearbeitungsrechte hat
    if (!canEdit()) {
        $message = 'Sie haben keine Berechtigung, um Items zu bearbeiten.';
        $messageType = 'danger';
    } else {
        $editMode = true;
        $id = $_GET['edit'];
        
        foreach ($items as $item) {
            if ($item['id'] === $id) {
                $currentItem = $item;
                break;
            }
        }
    }
}

// Erstellen-Modus
$createMode = isset($_GET['action']) && $_GET['action'] === 'new';

// Wenn Benutzer keine Bearbeitungsrechte hat, neue Erstellungen verbieten
if ($createMode && !canEdit()) {
    $message = 'Sie haben keine Berechtigung, um neue Items zu erstellen.';
    $messageType = 'danger';
    $createMode = false;
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?php echo $pageTitle; ?></h1>
        <?php if (canEdit()): ?>
        <a href="?action=new" class="btn btn-primary"><i class="fas fa-plus-circle"></i> Neues Item</a>
        <?php endif; ?>
    </div>
    
    <?php if (!empty($message)): ?>
    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
        <?php echo $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Schließen"></button>
    </div>
    <?php endif; ?>
    
    <?php if ($editMode || $createMode): ?>
    <div class="card bg-dark text-white mb-4">
        <div class="card-header">
            <h5 class="mb-0"><?php echo $editMode ? 'Item bearbeiten' : 'Neues Item erstellen'; ?></h5>
        </div>
        <div class="card-body">
            <form method="post" action="items.php">
                <?php if ($editMode): ?>
                <input type="hidden" name="id" value="<?php echo $currentItem['id']; ?>">
                <?php endif; ?>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control bg-dark text-white" id="name" name="name" 
                               value="<?php echo htmlspecialchars($currentItem['name']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label for="fraktion_id" class="form-label">Fraktion</label>
                        <select class="form-select bg-dark text-white" id="fraktion_id" name="fraktion_id" required>
                            <option value="">Fraktion auswählen</option>
                            <?php foreach ($fraktionen as $fraktion): ?>
                            <option value="<?php echo $fraktion['id']; ?>" <?php if ($currentItem['fraktion_id'] === $fraktion['id']) echo 'selected'; ?>>
                                <?php echo htmlspecialchars($fraktion['name']); ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="mb-3">
                    <label for="beschreibung" class="form-label">Beschreibung</label>
                    <textarea class="form-control bg-dark text-white" id="beschreibung" name="beschreibung" rows="3"><?php echo htmlspecialchars($currentItem['beschreibung']); ?></textarea>
                </div>
                
                <div class="mb-3">
                    <label class="form-label">Rezept</label>
                    <div id="rezept-container">
                        <?php 
                        // Existierende Rezeptbestandteile anzeigen
                        if (isset($currentItem['rezept']) && is_array($currentItem['rezept'])) {
                            foreach ($currentItem['rezept'] as $bestandteil) {
                                $bestandteilId = isset($bestandteil['id']) ? $bestandteil['id'] : '';
                                $menge = isset($bestandteil['menge']) ? $bestandteil['menge'] : 1;
                                echo '<div class="row rezept-zeile mb-2">';
                                echo '<div class="col-md-6">';
                                echo '<select class="form-select rezept-material-select bg-dark text-white" name="material_id[]" required>';
                                echo '<option value="">Material/Item auswählen</option>';
                                echo '<optgroup label="Materialien">';
                                foreach ($materialien as $material) {
                                    $selected = ($bestandteilId === 'material_' . $material['id']) ? 'selected' : '';
                                    echo "<option value=\"material_{$material['id']}\" {$selected}>" . htmlspecialchars($material['name']) . "</option>";
                                }
                                echo '</optgroup>';
                                echo '<optgroup label="Items">';
                                foreach ($items as $item) {
                                    if ($editMode && $item['id'] === $currentItem['id']) continue; // Ausschließen des aktuellen Items
                                    $selected = ($bestandteilId === 'item_' . $item['id']) ? 'selected' : '';
                                    echo "<option value=\"item_{$item['id']}\" {$selected}>" . htmlspecialchars($item['name']) . "</option>";
                                }
                                echo '</optgroup>';
                                echo '</select>';
                                echo '</div>';
                                echo '<div class="col-md-3">';
                                echo '<div class="input-group">';
                                echo "<input type=\"number\" class=\"form-control bg-dark text-white\" name=\"menge[]\" placeholder=\"Menge\" required min=\"1\" value=\"{$menge}\">";
                                echo '<span class="input-group-text bg-dark text-white">Stück</span>';
                                echo '</div>';
                                echo '</div>';
                                echo '<div class="col-md-3">';
                                echo '<button type="button" class="btn btn-outline-danger entferne-material">';
                                echo '<i class="fas fa-trash-alt"></i> Entfernen';
                                echo '</button>';
                                echo '</div>';
                                echo '</div>';
                            }
                        }
                        ?>
                    </div>
                    <button type="button" class="btn btn-outline-success" id="add-material">
                        <i class="fas fa-plus"></i> Material/Item hinzufügen
                    </button>
                </div>
                
                <div class="d-flex justify-content-between">
                    <button type="submit" name="submit_item" class="btn btn-primary">
                        <i class="fas fa-save"></i> <?php echo $editMode ? 'Aktualisieren' : 'Erstellen'; ?>
                    </button>
                    <a href="items.php" class="btn btn-secondary">
                        <i class="fas fa-times"></i> Abbrechen
                    </a>
                </div>
            </form>
        </div>
    </div>
    <?php else: ?>
    <div class="card bg-dark text-white">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">Items</h5>
                <div class="input-group w-50">
                    <span class="input-group-text bg-dark text-white border-secondary"><i class="fas fa-search"></i></span>
                    <input type="text" id="items-suche" class="form-control bg-dark text-white border-secondary" placeholder="Item suchen...">
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (count($items) > 0): ?>
            <div class="table-responsive">
                <table class="table table-dark table-hover" id="items-tabelle">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Fraktion</th>
                            <th>Rezeptbestandteile</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($items as $item): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td>
                                <?php 
                                $fraktionsName = "Nicht zugewiesen";
                                foreach ($fraktionen as $fraktion) {
                                    if ($fraktion['id'] === $item['fraktion_id']) {
                                        $fraktionsName = htmlspecialchars($fraktion['name']);
                                        break;
                                    }
                                }
                                echo $fraktionsName;
                                ?>
                            </td>
                            <td>
                                <?php
                                $rezept = isset($item['rezept']) ? $item['rezept'] : [];
                                $rezeptCount = count($rezept);
                                echo $rezeptCount . ' Bestandteile';
                                if ($rezeptCount > 0) {
                                    echo ' <button type="button" class="btn btn-sm btn-outline-info view-item-details" 
                                         data-id="' . $item['id'] . '" 
                                         data-name="' . htmlspecialchars($item['name']) . '">
                                         <i class="fas fa-eye"></i> Details
                                     </button>';
                                }
                                ?>
                            </td>
                            <td>
                                <?php if (canEdit()): ?>
                                <div class="btn-group" role="group">
                                    <a href="?edit=<?php echo $item['id']; ?>" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-edit"></i> Bearbeiten
                                    </a>
                                    <button type="button" class="btn btn-sm btn-outline-danger delete-item" 
                                            data-id="<?php echo $item['id']; ?>" 
                                            data-name="<?php echo htmlspecialchars($item['name']); ?>">
                                        <i class="fas fa-trash-alt"></i> Löschen
                                    </button>
                                </div>
                                <?php else: ?>
                                <span class="text-muted"><i class="fas fa-eye"></i> Nur Ansicht</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-center text-muted">Keine Items gefunden. Erstellen Sie ein neues Item.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<!-- Lösch-Bestätigungsdialog -->
<div class="modal fade" id="delete-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Item löschen</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <p>Sind Sie sicher, dass Sie das Item <span id="delete-item-name"></span> löschen möchten?</p>
                <p class="text-danger">Diese Aktion kann nicht rückgängig gemacht werden und entfernt auch alle Referenzen zu diesem Item in Rezepten.</p>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Abbrechen</button>
                <a href="#" id="confirm-delete" class="btn btn-danger">Löschen</a>
            </div>
        </div>
    </div>
</div>

<!-- Item-Details-Dialog -->
<div class="modal fade" id="item-details-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Rezept für <span id="item-name"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="card bg-dark border-secondary mb-3">
                            <div class="card-header">
                                <h6 class="mb-0">Rezeptbestandteile</h6>
                            </div>
                            <div class="card-body">
                                <div id="rezept-container">
                                    <table class="table table-dark table-striped mb-0">
                                        <thead>
                                            <tr>
                                                <th>Name</th>
                                                <th>Typ</th>
                                                <th>Menge</th>
                                            </tr>
                                        </thead>
                                        <tbody id="item-rezept-list">
                                            <!-- Wird dynamisch gefüllt mit Rezeptbestandteilen -->
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card bg-dark border-secondary">
                            <div class="card-header">
                                <h6 class="mb-0">Item-Informationen</h6>
                            </div>
                            <div class="card-body">
                                <p><strong>Fraktion:</strong> <span id="item-fraktion"></span></p>
                                <p><strong>Beschreibung:</strong> <span id="item-beschreibung"></span></p>
                            </div>
                        </div>
                        <div class="card bg-dark border-secondary mt-3">
                            <div class="card-header">
                                <h6 class="mb-0">Verwendung in anderen Rezepten</h6>
                            </div>
                            <div class="card-body">
                                <div id="item-verwendung-container">
                                    <!-- Wird dynamisch gefüllt mit Verwendungen -->
                                </div>
                            </div>
                        </div>
                        <div class="card bg-dark border-secondary mt-3">
                            <div class="card-header">
                                <h6 class="mb-0">Bezieht Bestandteile von</h6>
                            </div>
                            <div class="card-body">
                                <div id="item-bezieht-container">
                                    <!-- Wird dynamisch gefüllt mit Lieferanten -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <?php if (canEdit()): ?>
                <a href="#" id="edit-item-link" class="btn btn-primary">
                    <i class="fas fa-edit"></i> Bearbeiten
                </a>
                <?php endif; ?>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Schließen</button>
            </div>
        </div>
    </div>
</div>

<!-- Vorlage für neue Rezeptzeile -->
<template id="rezept-zeile-template">
    <div class="row rezept-zeile mb-2">
        <div class="col-md-6">
            <select class="form-select rezept-material-select bg-dark text-white" name="material_id[]" required>
                <option value="">Material/Item auswählen</option>
                <optgroup label="Materialien">
                    <?php foreach ($materialien as $material): ?>
                    <option value="material_<?php echo $material['id']; ?>"><?php echo htmlspecialchars($material['name']); ?></option>
                    <?php endforeach; ?>
                </optgroup>
                <optgroup label="Items">
                    <?php foreach ($items as $item): ?>
                    <?php if ($editMode && $item['id'] === $currentItem['id']) continue; // Ausschließen des aktuellen Items ?>
                    <option value="item_<?php echo $item['id']; ?>"><?php echo htmlspecialchars($item['name']); ?></option>
                    <?php endforeach; ?>
                </optgroup>
            </select>
        </div>
        <div class="col-md-3">
            <div class="input-group">
                <input type="number" class="form-control bg-dark text-white" name="menge[]" placeholder="Menge" required min="1" value="1">
                <span class="input-group-text bg-dark text-white">Stück</span>
            </div>
        </div>
        <div class="col-md-3">
            <button type="button" class="btn btn-outline-danger entferne-material">
                <i class="fas fa-trash-alt"></i> Entfernen
            </button>
        </div>
    </div>
</template>

<?php include 'includes/footer.php'; ?>
