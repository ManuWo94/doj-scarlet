<?php
/**
 * Hauptseite der Fraktionsverwaltung
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration und Funktionen
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Leite zum Dashboard oder Login weiter
if (isset($_SESSION['user_id'])) {
    header('Location: dashboard.php');
} else {
    header('Location: login.php');
}
exit;
