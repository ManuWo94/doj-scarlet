<?php
/**
 * Login-Seite für die Fraktionsverwaltung
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';

// Wenn der Benutzer bereits angemeldet ist, leite zum Dashboard weiter
if (isLoggedIn()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$success = '';

// Login-Formular verarbeiten
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    
    if (empty($username) || empty($password)) {
        $error = 'Bitte gib Benutzername und Passwort ein.';
    } else {
        $user = getBenutzerByUsername($username);
        
        if ($user && password_verify($password, $user['password'])) {
            // Login erfolgreich
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['user_can_edit'] = $user['role'] === 'admin' || (isset($user['can_edit']) && $user['can_edit']);
            
            // Prüfe, ob Passwort zurückgesetzt werden muss
            if (isset($user['password_reset_required']) && $user['password_reset_required']) {
                $_SESSION['password_reset_required'] = true;
                header('Location: password_reset.php');
                exit;
            }
            
            // Logge die Anmeldung
            logAktivität('fa-sign-in-alt', $username . ' hat sich angemeldet.');
            
            // Leite zum Dashboard weiter
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Ungültiger Benutzername oder Passwort.';
        }
    }
}

// Seiten-Header
$pageTitle = 'Login';
include 'includes/header.php';
?>

<div class="container mt-5">
    <div class="row justify-content-center">
        <div class="col-md-6">
            <div class="card bg-dark text-white">
                <div class="card-header">
                    <h4 class="mb-0">
                        <i class="fas fa-sign-in-alt"></i> Login - Fraktionsverwaltung
                    </h4>
                </div>
                <div class="card-body">
                    <?php if (!empty($error)) : ?>
                    <div class="alert alert-danger">
                        <?php echo htmlspecialchars($error); ?>
                    </div>
                    <?php endif; ?>
                    
                    <?php if (!empty($success)) : ?>
                    <div class="alert alert-success">
                        <?php echo htmlspecialchars($success); ?>
                    </div>
                    <?php endif; ?>
                    
                    <form method="post" action="login.php">
                        <div class="mb-3">
                            <label for="username" class="form-label">Benutzername</label>
                            <input type="text" class="form-control" id="username" name="username" required autofocus>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Passwort</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <div class="d-grid">
                            <button type="submit" class="btn btn-primary">Anmelden</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>