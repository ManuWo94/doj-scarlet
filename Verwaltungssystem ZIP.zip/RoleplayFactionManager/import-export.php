<?php
/**
 * Import/Export-Seite
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Import/Export";
$message = '';
$messageType = '';
$importData = [];

// Verarbeite Import-Formular
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import'])) {
    if (isset($_POST['importText']) && !empty($_POST['importText'])) {
        $importText = $_POST['importText'];
        
        try {
            $importData = analysiereImportText($importText);
            if (count($importData['fraktionen']) > 0 || count($importData['items']) > 0 || count($importData['materialien']) > 0) {
                $message = 'Daten erfolgreich analysiert. Bitte überprüfen Sie die erkannten Daten und speichern Sie diese.';
                $messageType = 'success';
            } else {
                $message = 'Keine gültigen Daten im Import gefunden.';
                $messageType = 'warning';
            }
        } catch (Exception $e) {
            $message = 'Fehler beim Analysieren der Importdaten: ' . $e->getMessage();
            $messageType = 'danger';
        }
    } else {
        $message = 'Bitte geben Sie Importdaten ein.';
        $messageType = 'warning';
    }
}

// Verarbeite Import-Bestätigung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_import'])) {
    $importedFraktionen = isset($_POST['import_fraktionen']) ? $_POST['import_fraktionen'] : [];
    $importedItems = isset($_POST['import_items']) ? $_POST['import_items'] : [];
    $importedMaterialien = isset($_POST['import_materialien']) ? $_POST['import_materialien'] : [];
    
    $erfolgreich = true;
    
    // Speichere Fraktionen
    foreach ($importedFraktionen as $fraktionId) {
        $fraktion = json_decode($_POST['fraktion_' . $fraktionId], true);
        if (!createFraktion($fraktion)) {
            $erfolgreich = false;
        }
    }
    
    // Speichere Materialien
    foreach ($importedMaterialien as $materialId) {
        $material = json_decode($_POST['material_' . $materialId], true);
        if (!createMaterial($material)) {
            $erfolgreich = false;
        }
    }
    
    // Speichere Items
    foreach ($importedItems as $itemId) {
        $item = json_decode($_POST['item_' . $itemId], true);
        if (!createItem($item)) {
            $erfolgreich = false;
        }
    }
    
    if ($erfolgreich) {
        $message = 'Importierte Daten erfolgreich gespeichert.';
        $messageType = 'success';
        logAktivität('fa-file-import', 'Daten importiert');
        $importData = []; // Zurücksetzen der Import-Daten
    } else {
        $message = 'Fehler beim Speichern der importierten Daten.';
        $messageType = 'danger';
    }
}

// Lade Daten für Export
$fraktionen = loadFraktionen();
$items = loadItems();
$materialien = loadMaterialien();

// Generiere Export-Daten
$exportData = [
    'fraktionen' => $fraktionen,
    'items' => $items,
    'materialien' => $materialien
];

$exportText = generateExportText($exportData);

include 'includes/header.php';
?>

<div class="container py-4">
    <h1 class="mb-4"><?php echo $pageTitle; ?></h1>
    
    <?php if (!empty($message)): ?>
    <div class="alert alert-<?php echo $messageType; ?> alert-dismissible fade show" role="alert">
        <?php echo $message; ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
    <?php endif; ?>
    
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card bg-dark text-white h-100">
                <div class="card-header">
                    <h5><i class="fas fa-file-export"></i> Export</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">Exportieren Sie alle Daten als Konfigurationsdateien.</p>
                    
                    <div class="mb-3">
                        <label for="exportText" class="form-label">Export-Text:</label>
                        <textarea class="form-control bg-dark text-white" id="exportText" rows="12" readonly><?php echo $exportText; ?></textarea>
                    </div>
                    
                    <div class="d-flex justify-content-between">
                        <button type="button" id="copy-export" class="btn btn-primary">
                            <i class="fas fa-copy"></i> In Zwischenablage kopieren
                        </button>
                        <button type="button" id="download-export" class="btn btn-outline-light">
                            <i class="fas fa-download"></i> Als Datei herunterladen
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-md-6 mb-4">
            <div class="card bg-dark text-white h-100">
                <div class="card-header">
                    <h5><i class="fas fa-file-import"></i> Import</h5>
                </div>
                <div class="card-body">
                    <p class="card-text">Importieren Sie Konfigurationsdateien in das System.</p>
                    
                    <form method="post" action="import-export.php">
                        <div class="mb-3">
                            <label for="importText" class="form-label">Konfigurationstext einfügen:</label>
                            <textarea class="form-control bg-dark text-white" id="importText" name="importText" rows="10" required></textarea>
                        </div>
                        
                        <div class="d-grid">
                            <button type="submit" name="import" class="btn btn-primary">
                                <i class="fas fa-search"></i> Konfiguration analysieren
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
    <?php if (!empty($importData)): ?>
    <div class="card bg-dark text-white mb-4">
        <div class="card-header">
            <h5><i class="fas fa-clipboard-check"></i> Import überprüfen</h5>
        </div>
        <div class="card-body">
            <form method="post" action="import-export.php">
                <?php if (!empty($importData['fraktionen'])): ?>
                <h6 class="mt-3 mb-2">Fraktionen:</h6>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th width="50">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="check-all-fraktionen" checked>
                                    </div>
                                </th>
                                <th>Name</th>
                                <th>Beschreibung</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($importData['fraktionen'] as $fraktion): ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input class="form-check-input fraktion-checkbox" type="checkbox" name="import_fraktionen[]" 
                                               value="<?php echo $fraktion['id']; ?>" id="fraktion-<?php echo $fraktion['id']; ?>" checked>
                                        <input type="hidden" name="fraktion_<?php echo $fraktion['id']; ?>" 
                                               value="<?php echo htmlspecialchars(json_encode($fraktion)); ?>">
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($fraktion['name']); ?></td>
                                <td><?php echo htmlspecialchars($fraktion['beschreibung']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($importData['materialien'])): ?>
                <h6 class="mt-4 mb-2">Materialien:</h6>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th width="50">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="check-all-materialien" checked>
                                    </div>
                                </th>
                                <th>Name</th>
                                <th>Fraktion</th>
                                <th>Beschreibung</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($importData['materialien'] as $material): ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input class="form-check-input material-checkbox" type="checkbox" name="import_materialien[]" 
                                               value="<?php echo $material['id']; ?>" id="material-<?php echo $material['id']; ?>" checked>
                                        <input type="hidden" name="material_<?php echo $material['id']; ?>" 
                                               value="<?php echo htmlspecialchars(json_encode($material)); ?>">
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($material['name']); ?></td>
                                <td>
                                    <?php 
                                    $fraktionName = "Unbekannt";
                                    foreach ($importData['fraktionen'] as $fraktion) {
                                        if ($fraktion['id'] === $material['fraktion_id']) {
                                            $fraktionName = $fraktion['name'];
                                            break;
                                        }
                                    }
                                    echo htmlspecialchars($fraktionName);
                                    ?>
                                </td>
                                <td><?php echo htmlspecialchars($material['beschreibung']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                
                <?php if (!empty($importData['items'])): ?>
                <h6 class="mt-4 mb-2">Items:</h6>
                <div class="table-responsive">
                    <table class="table table-dark table-hover">
                        <thead>
                            <tr>
                                <th width="50">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="check-all-items" checked>
                                    </div>
                                </th>
                                <th>Name</th>
                                <th>Fraktion</th>
                                <th>Rezeptbestandteile</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($importData['items'] as $item): ?>
                            <tr>
                                <td>
                                    <div class="form-check">
                                        <input class="form-check-input item-checkbox" type="checkbox" name="import_items[]" 
                                               value="<?php echo $item['id']; ?>" id="item-<?php echo $item['id']; ?>" checked>
                                        <input type="hidden" name="item_<?php echo $item['id']; ?>" 
                                               value="<?php echo htmlspecialchars(json_encode($item)); ?>">
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td>
                                    <?php 
                                    $fraktionName = "Unbekannt";
                                    foreach ($importData['fraktionen'] as $fraktion) {
                                        if ($fraktion['id'] === $item['fraktion_id']) {
                                            $fraktionName = $fraktion['name'];
                                            break;
                                        }
                                    }
                                    echo htmlspecialchars($fraktionName);
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    $rezept = isset($item['rezept']) ? $item['rezept'] : [];
                                    if (count($rezept) > 0) {
                                        echo '<ul class="mb-0 ps-3">';
                                        foreach ($rezept as $bestandteil) {
                                            $bestandteilName = "Unbekannt";
                                            $typ = isset($bestandteil['typ']) ? $bestandteil['typ'] : '';
                                            $id = isset($bestandteil['id']) ? $bestandteil['id'] : '';
                                            $menge = isset($bestandteil['menge']) ? $bestandteil['menge'] : 1;
                                            
                                            if ($typ === 'material') {
                                                foreach ($importData['materialien'] as $material) {
                                                    if ($material['id'] === $id) {
                                                        $bestandteilName = $material['name'];
                                                        break;
                                                    }
                                                }
                                            } elseif ($typ === 'item') {
                                                foreach ($importData['items'] as $innerItem) {
                                                    if ($innerItem['id'] === $id) {
                                                        $bestandteilName = $innerItem['name'];
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            echo '<li>' . htmlspecialchars($bestandteilName) . ' (' . $menge . 'x)</li>';
                                        }
                                        echo '</ul>';
                                    } else {
                                        echo 'Keine Rezeptbestandteile';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
                
                <div class="d-flex justify-content-between mt-4">
                    <button type="submit" name="save_import" class="btn btn-success">
                        <i class="fas fa-save"></i> Ausgewählte Daten importieren
                    </button>
                    <a href="import-export.php" class="btn btn-secondary">Abbrechen</a>
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php include 'includes/footer.php'; ?>
