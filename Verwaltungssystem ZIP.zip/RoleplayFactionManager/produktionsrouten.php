<?php
/**
 * Produktionsrouten Verwaltungsseite
 */

// Initialisiere die Session
session_start();

// Lade Konfiguration
require_once 'config/config.php';
require_once 'includes/functions.php';
require_once 'includes/data-handler.php';

// Wenn der Benutzer nicht angemeldet ist, leite zum Login weiter
if (!isLoggedIn()) {
    header('Location: login.php');
    exit;
}

$pageTitle = "Produktionsrouten";

// Lade alle Daten
$fraktionen = loadFraktionen();
$items = loadItems();
$materialien = loadMaterialien();

// Prüfe auf fehlende Produktionsrouten
$fehlendeRouten = prüfeFehlendeProduktionsrouten($fraktionen, $items, $materialien);

// Filtere nach Fraktion, wenn ausgewählt
$selectedFraktionId = isset($_GET['fraktion']) ? $_GET['fraktion'] : '';

// Erstelle die Routenstruktur
$routen = [];

// Für jedes Item die Produktionsroute erstellen
foreach ($items as $item) {
    // Wenn eine Fraktion ausgewählt ist und das Item nicht zu dieser Fraktion gehört, überspringen
    if (!empty($selectedFraktionId) && $item['fraktion_id'] !== $selectedFraktionId) {
        continue;
    }
    
    $route = erstelleProduktionsroute($item, $items, $materialien, $fraktionen);
    
    if (!empty($route)) {
        $routen[] = $route;
    }
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h1><?php echo $pageTitle; ?></h1>
        <div class="d-flex gap-3">
            <form method="get" class="d-flex">
                <select name="fraktion" class="form-select bg-dark text-white me-2" onchange="this.form.submit()">
                    <option value="">Alle Fraktionen</option>
                    <?php foreach ($fraktionen as $fraktion): ?>
                    <option value="<?php echo $fraktion['id']; ?>" <?php if ($selectedFraktionId === $fraktion['id']) echo 'selected'; ?>>
                        <?php echo htmlspecialchars($fraktion['name']); ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn btn-outline-secondary">Filtern</button>
            </form>
            
            <a href="produktionsrouten.php" class="btn btn-outline-secondary <?php if (empty($selectedFraktionId)) echo 'd-none'; ?>">
                <i class="fas fa-times"></i> Filter zurücksetzen
            </a>
        </div>
    </div>
    
    <?php if (count($fehlendeRouten) > 0): ?>
    <div class="alert alert-danger">
        <h5><i class="fas fa-exclamation-triangle"></i> Probleme mit Produktionsrouten entdeckt!</h5>
        <p>Es wurden Items/Materialien gefunden, die in Rezepten benötigt werden, aber keine vollständige Produktionsroute haben.</p>
        <ul>
            <?php foreach ($fehlendeRouten as $route): ?>
            <li>
                <strong class="text-danger"><?php echo htmlspecialchars($route['name']); ?></strong> 
                wird benötigt von: <?php echo htmlspecialchars($route['benötigtVon']); ?>
            </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>
    
    <div class="card bg-dark text-white mb-4">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5>Produktionsrouten</h5>
                <div class="input-group w-50">
                    <span class="input-group-text bg-dark text-white border-secondary"><i class="fas fa-search"></i></span>
                    <input type="text" id="routen-suche" class="form-control bg-dark text-white border-secondary" placeholder="Route suchen...">
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php if (count($routen) > 0): ?>
            <div class="table-responsive">
                <table class="table table-dark table-hover" id="routen-tabelle">
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Fraktion</th>
                            <th>Komponenten</th>
                            <th>Aktionen</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($routen as $route): ?>
                        <tr class="routen-eintrag">
                            <td><?php echo htmlspecialchars($route['name']); ?></td>
                            <td>
                                <span class="badge bg-primary"><?php echo htmlspecialchars($route['fraktion']); ?></span>
                            </td>
                            <td>
                                <?php
                                $zutatCount = count($route['zutaten']);
                                $fehlendeZutaten = 0;
                                
                                foreach ($route['zutaten'] as $zutat) {
                                    if ($zutat['fehlend']) {
                                        $fehlendeZutaten++;
                                    }
                                }
                                
                                echo $zutatCount . ' Komponenten';
                                
                                if ($fehlendeZutaten > 0) {
                                    echo ' <span class="badge bg-danger">' . $fehlendeZutaten . ' fehlend</span>';
                                }
                                ?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-info view-route-details" 
                                     data-id="<?php echo $route['id']; ?>" 
                                     data-name="<?php echo htmlspecialchars($route['name']); ?>">
                                     <i class="fas fa-eye"></i> Details anzeigen
                                </button>
                                <?php if (canEdit() && isset($route['id'])): ?>
                                <a href="items.php?edit=<?php echo $route['id']; ?>" class="btn btn-sm btn-outline-primary ms-1">
                                    <i class="fas fa-edit"></i> Item bearbeiten
                                </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php else: ?>
            <p class="text-center text-muted">
                <?php if (!empty($selectedFraktionId)): ?>
                Keine Produktionsrouten für die ausgewählte Fraktion gefunden.
                <?php else: ?>
                Keine Produktionsrouten gefunden. Bitte erstellen Sie Items mit Rezepten.
                <?php endif; ?>
            </p>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Produktionsrouten-Detail-Dialog -->
<div class="modal fade" id="route-details-modal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content bg-dark text-white">
            <div class="modal-header">
                <h5 class="modal-title">Produktionsroute: <span id="route-name"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div id="route-details-container">
                    <div class="text-center">
                        <i class="fas fa-spinner fa-spin"></i> Lade Produktionsroute...
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Schließen</button>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
