<?php
/**
 * Footer-Template für alle Seiten
 */
?>
    </main>
    
    <footer class="bg-dark text-white-50 text-center py-3 mt-5 border-top border-secondary">
        <div class="container">
            <p class="mb-0">Fraktionsverwaltung &copy; <?php echo date('Y'); ?> - Version <?php echo $config['version']; ?></p>
        </div>
    </footer>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <!-- Bootstrap 5 JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Select2 für verbesserte Dropdowns -->
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    
    <!-- Custom JS -->
    <script src="js/main.js"></script>
    
    <?php
    // Seiten-spezifische JS-Dateien laden
    $currentPage = basename($_SERVER['SCRIPT_NAME'], '.php');
    $jsFile = "js/{$currentPage}.js";
    
    if (file_exists($jsFile)): 
    ?>
    <script src="<?php echo $jsFile; ?>"></script>
    <?php endif; ?>
</body>
</html>
