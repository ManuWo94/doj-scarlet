<?php
/**
 * Hilfsfunktionen für die Fraktionsverwaltung
 */

/**
 * Generiert eine eindeutige ID
 * 
 * @return string
 */
function generateUniqueId() {
    return uniqid() . '_' . mt_rand(1000, 9999);
}

/**
 * Benutzerverwaltungsfunktionen
 */

/**
 * Prüft, ob ein Benutzer angemeldet ist
 * 
 * @return bool
 */
function isLoggedIn() {
    return isset($_SESSION['user_id']);
}

/**
 * Prüft, ob der angemeldete Benutzer ein Admin ist
 * 
 * @return bool
 */
function isAdmin() {
    return isLoggedIn() && isset($_SESSION['user_role']) && $_SESSION['user_role'] === 'admin';
}

/**
 * Prüft, ob der angemeldete Benutzer Bearbeitungsrechte hat
 * 
 * @return bool
 */
function canEdit() {
    return isLoggedIn() && (isAdmin() || $_SESSION['user_can_edit']);
}

/**
 * Gibt alle Benutzer zurück
 * 
 * @return array
 */
function getBenutzer() {
    $benutzer = json_decode(file_get_contents(BENUTZER_FILE), true);
    return $benutzer ?: [];
}

/**
 * Speichert alle Benutzer
 * 
 * @param array $benutzer
 * @return bool
 */
function saveBenutzer($benutzer) {
    return file_put_contents(BENUTZER_FILE, json_encode($benutzer, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false;
}

/**
 * Gibt einen Benutzer anhand seiner ID zurück
 * 
 * @param string $id
 * @return array|null
 */
function getBenutzerById($id) {
    $benutzer = getBenutzer();
    foreach ($benutzer as $user) {
        if ($user['id'] === $id) {
            return $user;
        }
    }
    return null;
}

/**
 * Gibt einen Benutzer anhand seines Benutzernamens zurück
 * 
 * @param string $username
 * @return array|null
 */
function getBenutzerByUsername($username) {
    $benutzer = getBenutzer();
    foreach ($benutzer as $user) {
        if (strtolower($user['username']) === strtolower($username)) {
            return $user;
        }
    }
    return null;
}

/**
 * Erstellt einen neuen Benutzer
 * 
 * @param string $username
 * @param string $password
 * @param bool $canEdit
 * @return bool
 */
function createBenutzer($username, $password, $canEdit = false) {
    if (getBenutzerByUsername($username)) {
        return false; // Benutzer existiert bereits
    }
    
    $benutzer = getBenutzer();
    $benutzer[] = [
        'id' => generateUniqueId(),
        'username' => $username,
        'password' => password_hash($password, PASSWORD_DEFAULT),
        'role' => 'user',
        'can_edit' => $canEdit,
        'password_reset_required' => true,
        'created_at' => date('Y-m-d H:i:s')
    ];
    
    return saveBenutzer($benutzer);
}

/**
 * Aktualisiert einen Benutzer
 * 
 * @param string $id
 * @param array $data
 * @return bool
 */
function updateBenutzer($id, $data) {
    $benutzer = getBenutzer();
    foreach ($benutzer as $key => $user) {
        if ($user['id'] === $id) {
            $benutzer[$key] = array_merge($user, $data);
            return saveBenutzer($benutzer);
        }
    }
    return false;
}

/**
 * Löscht einen Benutzer
 * 
 * @param string $id
 * @return bool
 */
function deleteBenutzer($id) {
    $benutzer = getBenutzer();
    foreach ($benutzer as $key => $user) {
        if ($user['id'] === $id && $user['role'] !== 'admin') {
            unset($benutzer[$key]);
            return saveBenutzer(array_values($benutzer));
        }
    }
    return false;
}

/**
 * Loggt eine Aktivität im System
 * 
 * @param string $icon Font Awesome Icon-Klasse
 * @param string $text Beschreibung der Aktivität
 * @return bool
 */
function logAktivität($icon, $text) {
    $aktivitäten = json_decode(file_get_contents(AKTIVITÄTEN_FILE), true);
    
    // Neue Aktivität hinzufügen
    $aktivitäten[] = [
        'icon' => $icon,
        'text' => $text,
        'zeit' => date('Y-m-d H:i:s')
    ];
    
    // Auf maximale Anzahl begrenzen
    if (count($aktivitäten) > MAX_AKTIVITÄTEN) {
        $aktivitäten = array_slice($aktivitäten, -MAX_AKTIVITÄTEN);
    }
    
    return file_put_contents(AKTIVITÄTEN_FILE, json_encode($aktivitäten, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

/**
 * Lädt die letzten Aktivitäten
 * 
 * @param int $limit Maximale Anzahl der zurückgegebenen Aktivitäten
 * @return array
 */
function getAktivitäten($limit = 10) {
    $aktivitäten = json_decode(file_get_contents(AKTIVITÄTEN_FILE), true);
    
    // Sortieren nach Zeit absteigend
    usort($aktivitäten, function($a, $b) {
        return strtotime($b['zeit']) - strtotime($a['zeit']);
    });
    
    // Auf gewünschte Anzahl begrenzen
    return array_slice($aktivitäten, 0, $limit);
}

/**
 * Prüft auf fehlende Produktionsrouten (Items/Materialien ohne Zuordnung)
 * 
 * @param array $fraktionen Alle Fraktionen
 * @param array $items Alle Items
 * @param array $materialien Alle Materialien
 * @return array Liste der fehlenden Routen
 */
function prüfeFehlendeProduktionsrouten($fraktionen, $items, $materialien) {
    $fehlendeRouten = [];
    $alleRezeptBestandteile = [];
    
    // Sammle alle Rezeptbestandteile
    foreach ($items as $item) {
        if (isset($item['rezept']) && is_array($item['rezept'])) {
            foreach ($item['rezept'] as $bestandteil) {
                $typ = isset($bestandteil['typ']) ? $bestandteil['typ'] : '';
                $id = isset($bestandteil['id']) ? $bestandteil['id'] : '';
                
                if (!empty($typ) && !empty($id)) {
                    $key = $typ . '_' . $id;
                    if (!isset($alleRezeptBestandteile[$key])) {
                        $alleRezeptBestandteile[$key] = [
                            'typ' => $typ,
                            'id' => $id,
                            'verwendetIn' => []
                        ];
                    }
                    $alleRezeptBestandteile[$key]['verwendetIn'][] = $item['name'];
                }
            }
        }
    }
    
    // Prüfe, ob alle Materialien einer Fraktion zugeordnet sind
    foreach ($materialien as $material) {
        $key = 'material_' . $material['id'];
        
        // Wenn das Material in einem Rezept verwendet wird
        if (isset($alleRezeptBestandteile[$key])) {
            // Wenn das Material keiner Fraktion zugeordnet ist
            if (empty($material['fraktion_id'])) {
                $fehlendeRouten[] = [
                    'id' => $material['id'],
                    'name' => $material['name'],
                    'typ' => 'material',
                    'benötigtVon' => implode(', ', $alleRezeptBestandteile[$key]['verwendetIn'])
                ];
            }
        }
    }
    
    // Prüfe, ob alle Items einer Fraktion zugeordnet sind
    foreach ($items as $item) {
        $key = 'item_' . $item['id'];
        
        // Wenn das Item in einem Rezept verwendet wird
        if (isset($alleRezeptBestandteile[$key])) {
            // Wenn das Item keiner Fraktion zugeordnet ist
            if (empty($item['fraktion_id'])) {
                $fehlendeRouten[] = [
                    'id' => $item['id'],
                    'name' => $item['name'],
                    'typ' => 'item',
                    'benötigtVon' => implode(', ', $alleRezeptBestandteile[$key]['verwendetIn'])
                ];
            }
        }
    }
    
    return $fehlendeRouten;
}

/**
 * Erstellt die Produktionsroute für ein Item
 * 
 * @param array $item Das zu untersuchende Item
 * @param array $alleItems Alle verfügbaren Items
 * @param array $alleMaterialien Alle verfügbaren Materialien
 * @param array $alleFraktionen Alle verfügbaren Fraktionen
 * @return array|null Die Produktionsroute oder null, wenn Item keine Fraktion hat
 */
function erstelleProduktionsroute($item, $alleItems, $alleMaterialien, $alleFraktionen) {
    // Item muss einer Fraktion zugeordnet sein
    if (empty($item['fraktion_id'])) {
        return null;
    }
    
    // Fraktionsname ermitteln
    $fraktionsName = 'Unbekannt';
    foreach ($alleFraktionen as $fraktion) {
        if ($fraktion['id'] === $item['fraktion_id']) {
            $fraktionsName = $fraktion['name'];
            break;
        }
    }
    
    $route = [
        'id' => $item['id'],
        'name' => $item['name'],
        'beschreibung' => isset($item['beschreibung']) ? $item['beschreibung'] : '',
        'fraktion' => $fraktionsName,
        'fraktion_id' => $item['fraktion_id'],
        'zutaten' => []
    ];
    
    // Rezeptbestandteile ermitteln
    if (isset($item['rezept']) && is_array($item['rezept'])) {
        foreach ($item['rezept'] as $bestandteil) {
            $zutatenTyp = isset($bestandteil['typ']) ? $bestandteil['typ'] : '';
            $zutatenId = isset($bestandteil['id']) ? $bestandteil['id'] : '';
            $menge = isset($bestandteil['menge']) ? $bestandteil['menge'] : 1;
            
            $zutat = [
                'id' => $zutatenId,
                'typ' => $zutatenTyp,
                'name' => 'Unbekannt',
                'menge' => $menge,
                'fraktion' => 'Keine Fraktion',
                'fraktion_id' => '',
                'fehlend' => true,
                'unterkomponenten' => []
            ];
            
            // Informationen abhängig vom Typ des Bestandteils hinzufügen
            if ($zutatenTyp === 'material') {
                foreach ($alleMaterialien as $material) {
                    if ($material['id'] === $zutatenId) {
                        $zutat['name'] = $material['name'];
                        $zutat['fehlend'] = empty($material['fraktion_id']);
                        
                        if (!empty($material['fraktion_id'])) {
                            $zutat['fraktion_id'] = $material['fraktion_id'];
                            
                            foreach ($alleFraktionen as $fraktion) {
                                if ($fraktion['id'] === $material['fraktion_id']) {
                                    $zutat['fraktion'] = $fraktion['name'];
                                    break;
                                }
                            }
                        }
                        
                        break;
                    }
                }
            } elseif ($zutatenTyp === 'item') {
                foreach ($alleItems as $unterItem) {
                    if ($unterItem['id'] === $zutatenId) {
                        $zutat['name'] = $unterItem['name'];
                        $zutat['fehlend'] = empty($unterItem['fraktion_id']);
                        
                        if (!empty($unterItem['fraktion_id'])) {
                            $zutat['fraktion_id'] = $unterItem['fraktion_id'];
                            
                            foreach ($alleFraktionen as $fraktion) {
                                if ($fraktion['id'] === $unterItem['fraktion_id']) {
                                    $zutat['fraktion'] = $fraktion['name'];
                                    break;
                                }
                            }
                        }
                        
                        // Rekursiv Unterkomponenten dieses Items hinzufügen
                        if (isset($unterItem['rezept']) && is_array($unterItem['rezept'])) {
                            foreach ($unterItem['rezept'] as $unterBestandteil) {
                                $unterTyp = isset($unterBestandteil['typ']) ? $unterBestandteil['typ'] : '';
                                $unterId = isset($unterBestandteil['id']) ? $unterBestandteil['id'] : '';
                                $unterMenge = isset($unterBestandteil['menge']) ? $unterBestandteil['menge'] : 1;
                                
                                $unterKomponente = [
                                    'id' => $unterId,
                                    'typ' => $unterTyp,
                                    'name' => 'Unbekannt',
                                    'menge' => $unterMenge,
                                    'fraktion' => 'Keine Fraktion',
                                    'fraktion_id' => '',
                                    'fehlend' => true
                                ];
                                
                                if ($unterTyp === 'material') {
                                    foreach ($alleMaterialien as $material) {
                                        if ($material['id'] === $unterId) {
                                            $unterKomponente['name'] = $material['name'];
                                            $unterKomponente['fehlend'] = empty($material['fraktion_id']);
                                            
                                            if (!empty($material['fraktion_id'])) {
                                                $unterKomponente['fraktion_id'] = $material['fraktion_id'];
                                                
                                                foreach ($alleFraktionen as $fraktion) {
                                                    if ($fraktion['id'] === $material['fraktion_id']) {
                                                        $unterKomponente['fraktion'] = $fraktion['name'];
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            break;
                                        }
                                    }
                                } elseif ($unterTyp === 'item') {
                                    foreach ($alleItems as $unterUnterItem) {
                                        if ($unterUnterItem['id'] === $unterId) {
                                            $unterKomponente['name'] = $unterUnterItem['name'];
                                            $unterKomponente['fehlend'] = empty($unterUnterItem['fraktion_id']);
                                            
                                            if (!empty($unterUnterItem['fraktion_id'])) {
                                                $unterKomponente['fraktion_id'] = $unterUnterItem['fraktion_id'];
                                                
                                                foreach ($alleFraktionen as $fraktion) {
                                                    if ($fraktion['id'] === $unterUnterItem['fraktion_id']) {
                                                        $unterKomponente['fraktion'] = $fraktion['name'];
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                $zutat['unterkomponenten'][] = $unterKomponente;
                            }
                        }
                        
                        break;
                    }
                }
            }
            
            $route['zutaten'][] = $zutat;
        }
    }
    
    return $route;
}

/**
 * Ermittelt, in welchen Rezepten ein Material/Item verwendet wird
 * 
 * @param string $typ 'material' oder 'item'
 * @param string $id ID des Materials/Items
 * @param array $items Alle Items
 * @return array Liste der Items, die das Material/Item verwenden
 */
function getVerwendungenInRezepten($typ, $id, $items) {
    $verwendungen = [];
    
    foreach ($items as $item) {
        if (isset($item['rezept']) && is_array($item['rezept'])) {
            foreach ($item['rezept'] as $bestandteil) {
                $bestandteilTyp = isset($bestandteil['typ']) ? $bestandteil['typ'] : '';
                $bestandteilId = isset($bestandteil['id']) ? $bestandteil['id'] : '';
                
                if ($bestandteilTyp === $typ && $bestandteilId === $id) {
                    $verwendungen[] = $item;
                    break;
                }
            }
        }
    }
    
    return $verwendungen;
}

/**
 * Ermittelt alle Items, die einer Fraktion zugeordnet sind
 * 
 * @param string $fraktionId ID der Fraktion
 * @return array Liste der Items
 */
function getItemsForFraktion($fraktionId) {
    $items = loadItems();
    $fraktionsItems = [];
    
    foreach ($items as $item) {
        if (isset($item['fraktion_id']) && $item['fraktion_id'] === $fraktionId) {
            $fraktionsItems[] = $item;
        }
    }
    
    return $fraktionsItems;
}

/**
 * Erzeugt einen Export-Text aller Daten
 * 
 * @param array $data Die zu exportierenden Daten
 * @return string
 */
function generateExportText($data) {
    $exportText = "### FRAKTIONSVERWALTUNG EXPORT ###\n";
    $exportText .= "### Erstellt am: " . date('Y-m-d H:i:s') . " ###\n\n";
    
    // Fraktionen exportieren
    $exportText .= "## FRAKTIONEN ##\n";
    foreach ($data['fraktionen'] as $fraktion) {
        $exportText .= "FRAKTION: " . $fraktion['name'] . "\n";
        $exportText .= "ID: " . $fraktion['id'] . "\n";
        $exportText .= "BESCHREIBUNG: " . $fraktion['beschreibung'] . "\n";
        $exportText .= "---\n";
    }
    $exportText .= "\n";
    
    // Materialien exportieren
    $exportText .= "## MATERIALIEN ##\n";
    foreach ($data['materialien'] as $material) {
        $exportText .= "MATERIAL: " . $material['name'] . "\n";
        $exportText .= "ID: " . $material['id'] . "\n";
        
        // Fraktion finden
        $fraktionsName = "Keine Fraktion";
        foreach ($data['fraktionen'] as $fraktion) {
            if ($fraktion['id'] === $material['fraktion_id']) {
                $fraktionsName = $fraktion['name'];
                break;
            }
        }
        
        $exportText .= "FRAKTION: " . $fraktionsName . "\n";
        $exportText .= "FRAKTION_ID: " . $material['fraktion_id'] . "\n";
        $exportText .= "BESCHREIBUNG: " . $material['beschreibung'] . "\n";
        $exportText .= "---\n";
    }
    $exportText .= "\n";
    
    // Items exportieren
    $exportText .= "## ITEMS ##\n";
    foreach ($data['items'] as $item) {
        $exportText .= "ITEM: " . $item['name'] . "\n";
        $exportText .= "ID: " . $item['id'] . "\n";
        
        // Fraktion finden
        $fraktionsName = "Keine Fraktion";
        foreach ($data['fraktionen'] as $fraktion) {
            if ($fraktion['id'] === $item['fraktion_id']) {
                $fraktionsName = $fraktion['name'];
                break;
            }
        }
        
        $exportText .= "FRAKTION: " . $fraktionsName . "\n";
        $exportText .= "FRAKTION_ID: " . $item['fraktion_id'] . "\n";
        $exportText .= "BESCHREIBUNG: " . $item['beschreibung'] . "\n";
        
        // Rezept exportieren
        if (isset($item['rezept']) && is_array($item['rezept']) && count($item['rezept']) > 0) {
            $exportText .= "REZEPT:\n";
            
            foreach ($item['rezept'] as $bestandteil) {
                $bestandteilTyp = isset($bestandteil['typ']) ? $bestandteil['typ'] : '';
                $bestandteilId = isset($bestandteil['id']) ? $bestandteil['id'] : '';
                $bestandteilMenge = isset($bestandteil['menge']) ? $bestandteil['menge'] : 1;
                
                $bestandteilName = "Unbekannt";
                
                if ($bestandteilTyp === 'material') {
                    foreach ($data['materialien'] as $material) {
                        if ($material['id'] === $bestandteilId) {
                            $bestandteilName = $material['name'];
                            break;
                        }
                    }
                } elseif ($bestandteilTyp === 'item') {
                    foreach ($data['items'] as $innerItem) {
                        if ($innerItem['id'] === $bestandteilId) {
                            $bestandteilName = $innerItem['name'];
                            break;
                        }
                    }
                }
                
                $exportText .= "  - " . $bestandteilName . " (" . $bestandteilTyp . ", " . $bestandteilMenge . "x)\n";
            }
        } else {
            $exportText .= "REZEPT: Keine Zutaten\n";
        }
        
        $exportText .= "---\n";
    }
    
    return $exportText;
}

/**
 * Analysiert einen Import-Text und extrahiert Fraktionen, Items und Materialien
 * 
 * @param string $importText Der zu analysierende Text
 * @return array Die extrahierten Daten
 */
function analysiereImportText($importText) {
    $result = [
        'fraktionen' => [],
        'materialien' => [],
        'items' => []
    ];
    
    // Zeilen aufteilen und Leerzeilen entfernen
    $lines = array_filter(explode("\n", $importText), function($line) {
        return trim($line) !== '';
    });
    
    $currentSection = null;
    $currentObject = null;
    $currentRezept = [];
    
    foreach ($lines as $line) {
        $line = trim($line);
        
        // Abschnittsüberschriften erkennen
        if (strpos($line, '## FRAKTIONEN ##') === 0) {
            $currentSection = 'fraktionen';
            continue;
        } elseif (strpos($line, '## MATERIALIEN ##') === 0) {
            $currentSection = 'materialien';
            continue;
        } elseif (strpos($line, '## ITEMS ##') === 0) {
            $currentSection = 'items';
            continue;
        }
        
        // Objekt-Trenner
        if ($line === '---') {
            if ($currentObject !== null) {
                if ($currentSection === 'items' && !empty($currentRezept)) {
                    $currentObject['rezept'] = $currentRezept;
                    $currentRezept = [];
                }
                
                if (!empty($currentObject['name'])) {
                    $result[$currentSection][] = $currentObject;
                }
            }
            
            $currentObject = [
                'id' => generateUniqueId() // Neue ID für importierte Objekte
            ];
            continue;
        }
        
        // Wenn kein Abschnitt oder kein Objekt aktiv ist, weitergehen
        if ($currentSection === null || $currentObject === null) {
            continue;
        }
        
        // Objekteigenschaften parsen
        if (strpos($line, 'FRAKTION: ') === 0 && $currentSection === 'fraktionen') {
            $currentObject['name'] = trim(substr($line, 10));
        } elseif (strpos($line, 'MATERIAL: ') === 0 && $currentSection === 'materialien') {
            $currentObject['name'] = trim(substr($line, 10));
        } elseif (strpos($line, 'ITEM: ') === 0 && $currentSection === 'items') {
            $currentObject['name'] = trim(substr($line, 6));
        } elseif (strpos($line, 'ID: ') === 0) {
            // Original-ID ignorieren, wir haben bereits eine neue generiert
            continue;
        } elseif (strpos($line, 'BESCHREIBUNG: ') === 0) {
            $currentObject['beschreibung'] = trim(substr($line, 14));
        } elseif (strpos($line, 'FRAKTION_ID: ') === 0) {
            // Fraktion-ID wird später zugeordnet
            $currentObject['fraktion_id'] = '';
        } elseif (strpos($line, 'FRAKTION: ') === 0 && $currentSection !== 'fraktionen') {
            // Fraktion nach Namen suchen und ID zuordnen
            $fraktionsName = trim(substr($line, 10));
            
            if ($fraktionsName !== "Keine Fraktion") {
                // Prüfen, ob die Fraktion bereits importiert wurde
                foreach ($result['fraktionen'] as $fraktion) {
                    if ($fraktion['name'] === $fraktionsName) {
                        $currentObject['fraktion_id'] = $fraktion['id'];
                        break;
                    }
                }
            }
        } elseif (strpos($line, 'REZEPT:') === 0) {
            // Nächste Zeilen enthalten Rezeptbestandteile
            continue;
        } elseif (strpos($line, '  - ') === 0 && $currentSection === 'items') {
            // Rezeptbestandteil parsen: "  - Material/Item-Name (Typ, Anzahlx)"
            $bestandteilInfo = trim(substr($line, 4));
            
            if (preg_match('/^(.+) \((material|item), (\d+)x\)$/', $bestandteilInfo, $matches)) {
                $bestandteilName = trim($matches[1]);
                $bestandteilTyp = $matches[2];
                $bestandteilMenge = intval($matches[3]);
                
                $bestandteilId = '';
                
                // Bestandteil-ID finden
                if ($bestandteilTyp === 'material') {
                    foreach ($result['materialien'] as $material) {
                        if ($material['name'] === $bestandteilName) {
                            $bestandteilId = $material['id'];
                            break;
                        }
                    }
                } elseif ($bestandteilTyp === 'item') {
                    foreach ($result['items'] as $item) {
                        if ($item['name'] === $bestandteilName) {
                            $bestandteilId = $item['id'];
                            break;
                        }
                    }
                }
                
                if (!empty($bestandteilId)) {
                    $currentRezept[] = [
                        'typ' => $bestandteilTyp,
                        'id' => $bestandteilId,
                        'menge' => $bestandteilMenge
                    ];
                }
            }
        }
    }
    
    // Letztes Objekt hinzufügen, falls vorhanden
    if ($currentObject !== null && !empty($currentObject['name'])) {
        if ($currentSection === 'items' && !empty($currentRezept)) {
            $currentObject['rezept'] = $currentRezept;
        }
        
        $result[$currentSection][] = $currentObject;
    }
    
    return $result;
}
